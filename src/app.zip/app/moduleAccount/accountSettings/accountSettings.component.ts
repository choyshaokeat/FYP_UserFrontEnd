import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FileUploader } from 'ng2-file-upload';

import { ApiFrontEndService } from '../../services/api-front-end.service';
import { ApiBackEndService } from '../../services/api-back-end.service';
import { DataService } from '../../services/data.service';
import { EncrDecrService } from '../../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-accountSettings',
  templateUrl: './accountSettings.component.html'
})
export class AccountSettingsComponent implements OnInit {

  merchant_profile: any;
  cities: any;
  gender = ['Male', 'Female'];
  loginData: any;

  uploader: FileUploader = new FileUploader({});
  selectedfileName: string = '';

  currentMerchantInfo: any;
  country: any;
  modal_data: any;
  clientName: any;
  clientICNum: any;
  clientEmail: any;
  clientContact: any;
  clientPW: any;
  clientHomeAdd: any;
  clientCountry: any;
  message: any;
  code: any;
  code_button_status: any = true;
  form = this.fb.group({
    merchant_verification_code: ['', [
      Validators.required,
      Validators.minLength(6),
    ]],
    merchant_owner_pw_1: ['', [
      Validators.required,
      Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$'),
      Validators.minLength(8),
    ]],
    merchant_owner_pw_2: ['', [
      Validators.required,
      Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$'),
      Validators.minLength(8),
    ]]
  })


  constructor(
    private API: ApiFrontEndService,
    private ApiBackEndService: ApiBackEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder
  ) { }

  async ngOnInit() {
    try {
      await this.subscribeData();
    }
    catch (err) {
      console.error(err);
    };

    this.uploader = new FileUploader({
      url: this.ApiBackEndService.getImageAPI(),
      itemAlias: 'image'
    });
    this.uploader.onAfterAddingFile = (file: any) => {
      file.withCredentials = false; //bypass CORS
      this.selectedfileName = file.file.name;
    };
  }

  get f() {
    return this.form.controls;
  }


  subscribeData() {
    this.DataService.currentClientInfo.subscribe(
      data => {
        var clientInfo = this.EncrDecrService.decryptObject('client', data);
        this.clientName = clientInfo.clientName;
        this.clientICNum = clientInfo.clientICNum;
        this.clientEmail = clientInfo.clientEmail;
        this.clientContact = clientInfo.clientContact;
        this.clientPW = clientInfo.clientPW;
        this.clientHomeAdd = clientInfo.clientHomeAdd;
        this.clientCountry = clientInfo.clientCountry;
      }
    );
    this.DataService.currentCountry.subscribe(
      data => {
        this.country = data;
      }
    );

  }


  updateClientInfo() {
    let data = {
      type: 'info',
      clientID: this.DataService.publicAuth.clientID,
      clientName: this.clientName,
      clientICNum: this.clientICNum,
      clientEmail: this.clientEmail,
      clientContact: this.clientContact,
      clientHomeAdd: this.clientHomeAdd,
      clientCountry: this.clientCountry
    }
    return new Promise(async (resolve, reject) => {
      try {
        this.spinner.show();
        var data_client = await this.API.updateClientInfo(data);
        await this.DataService.syncData('info');
        await this.subscribeData();
        var res = { data_client };
        setTimeout(() => {this.spinner.hide();},500);
        resolve(res);
      }
      catch (err) {
        console.error(data, err);
        reject(err);
      }
    });
  }


  update_password(value) {
    let data = {
      type: 'password',
      clientID: this.DataService.publicAuth.clientID,
      clientEmail: this.clientEmail,
      clientPW: value.client_pw_2,
    }
    return new Promise(async (resolve, reject) => {
      try {
        this.spinner.show();
        var data_merchant = await this.API.updateClientInfo(data);
        data_merchant = data_merchant;
        var res = { data_merchant };
        setTimeout(() => {this.spinner.hide();},500);
        resolve(res);
      }
      catch (err) {
        console.error(data, err);
        reject(err);
      }
    });
  }


  uploadImage() {
    this.uploader.onAfterAddingFile = (file: any) => {
      file.withCredentials = false; //bypass CORS
      this.selectedfileName = file.file.name;
    };
    var type = 'f';
    var id = 'id-AAAA';
    this.uploader.onBuildItemForm = (fileItem: any, form: any) => {
      form.append('type', type);
      form.append('id', id);
    };
    this.uploader.uploadAll();
    this.uploader.onSuccessItem = (item: any, response, status: number, headers: any): any => {
      try {
        this.selectedfileName = '';
        if ( typeof response == 'string' ) response = JSON.parse(response);
        console.log(response);
      }
      catch (err) {
        console.log(err);
      }
    }
  }

  async send_code() {
    this.code_button_status = false;
    setTimeout(() => {
      this.code_button_status = true;
    }, 5000);
    this.code = Math.floor(100000 + Math.random() * 900000);
    var html: './mail.html';
    var code = {
      type: 'verification_code',
      to: this.clientEmail,
      from: 'verification@foododo.co',
      subject: 'Verification Code',
      text: this.code,
      html: '<strong>Your Code is '+ this.code +' </strong>',
    }
    await this.API.registerVerificationCode(code);
    console.log(this.code);
    // console.log(this.code_button_status);
  }

  submit() {
    if (this.form.status === 'VALID') {
      return new Promise(async (resolve, reject) => {
        try {
            var merchant_data = await this.update_password(this.form.value);
            $('#modal_change_pw').modal('hide');
            var res = merchant_data;
            resolve(res);
        }
        catch (err) {
          console.error(merchant_data, err);
          reject(err);
        }
      });
    }
  }

  async modalEvent(data, type) {
    this.modal_data = data;
    console.log(this.modal_data);
    if (type == 'change_pw') {
      $('#modal_change_pw').modal('show');
    }
  }

  update_client_profile() {
    
  }

}
