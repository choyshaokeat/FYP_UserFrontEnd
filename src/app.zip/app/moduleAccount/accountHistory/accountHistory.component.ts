import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DataService } from '../../services/data.service';
import { NgxSpinnerService } from "ngx-spinner";

declare var $: any;

@Component({
  selector: 'app-accountHistory',
  templateUrl: './accountHistory.component.html'
})
export class AccountHistoryComponent implements OnInit {

  orders: any;
  modalData: any = '';
  modalDataDetails: any = '';
  modalPaymentStatus: any = '';
  modalDataTotal: any = '';

  constructor(
    private router: Router,
    private DataService: DataService,
    private spinner: NgxSpinnerService,
    ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    await this.subscribeData();
    console.log(this.orders);
    //this.router.navigate(['history/orders']);
  }

  async subscribeData() {
    this.DataService.currentOrders.subscribe(
      data => {
        this.orders = data;
      }
    );
  }

  async modalEvent(type, data) {
    if (type == 'order') {
      this.DataService.updateOrdersDetails(await this.DataService.getOrdersDetails(data));
      this.modalData = data;
      console.log(this.modalData);
      this.modalDataDetails =  await this.DataService.getOrdersDetails(data);
      this.modalDataTotal = await this.DataService.calculateTotal(this.modalDataDetails);
      $('#modalOrder').modal('show');
    }
  }

  async payment() {
    $('#modalOrder').modal('hide');
    this.spinner.show();
    this.DataService.updateOrderInfo(this.modalData);
    this.router.navigate([`payment`]);
    this.spinner.hide();
  }
  

}
