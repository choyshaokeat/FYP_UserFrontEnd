import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { ApiFrontEndService } from '../../../services/api-front-end.service';
import { DataService } from '../../../services/data.service';
import { EncrDecrService } from '../../../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-accountHistoryReservation',
  templateUrl: './accountHistoryReservation.component.html'
})
export class AccountHistoryReservationComponent implements OnInit {

  reservation: any;
  modalData: any = '';
  modalDataDetails: any = '';
  modalPaymentStatus: any = '';
  modalDataTotal: any = '';

  constructor(
    private router: Router,
    private DataService: DataService,
    private spinner: NgxSpinnerService,
    ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    await this.subscribeData();
    console.log(this.reservation);
    //this.router.navigate(['history/orders']);
  }

  async subscribeData() {
    this.DataService.currentReservation.subscribe(
      data => {
        this.reservation = data;
      }
    );
  }

  async modalEvent(type, data) {
    if (type == 'order') {
      this.DataService.updateOrdersDetails(await this.DataService.getReservationDetails(data));
      this.modalData = data;
      console.log(this.modalData);
      this.modalDataDetails =  await this.DataService.getReservationDetails(data);
      this.modalDataTotal = await this.DataService.calculateTotal(this.modalDataDetails);
      $('#modalOrder').modal('show');
    }
  }

  async payment() {
    $('#modalOrder').modal('hide');
    this.spinner.show();
    this.DataService.updateOrderInfo(this.modalData);
    this.router.navigate([`payment`]);
    this.spinner.hide();
  }
}
