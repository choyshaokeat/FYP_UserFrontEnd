import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';
import * as moment from 'moment';

declare var $: any;

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'
})
export class ConfirmationComponent implements OnInit {

  publicAuth: any;
  searchString: any;
  currentMerchantTableFitPax: any;
  exchange: any;
  reservationStatus: any = false;
  form = this.fb.group({
    clientName: ['', [
      Validators.required,
    ]],
    clientContact: ['', [
      Validators.required,
      Validators.minLength(6),
    ]],
    clientEmail: ['', [
      Validators.required,
      Validators.email,
    ]],
    clientRemarks: ['', [
    ]],
  })

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private EncrDecrService: EncrDecrService,
    private fb: FormBuilder,
    private ActivatedRoute: ActivatedRoute
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    await this.subscribeData();
    await this.param();
    console.log(this.searchString);
  }

  get f() {
    return this.form.controls;
  }

  async param() {
    this.ActivatedRoute.paramMap.subscribe(async (params) => {
      try {
        var params = params['params'];
        if (params['exchange'] != undefined) {
          this.exchange = this.EncrDecrService.decryptObject('client', params['exchange']);
          console.log(this.exchange);
          if (this.exchange != undefined) {

          }
        }
      }
      catch (err) {
        console.error(err);
      }
    });
  }


  async subscribeData() {
    this.publicAuth = this.DataService.publicAuth;
    this.form.controls['clientName'].setValue(this.publicAuth.clientName);
    this.form.controls['clientContact'].setValue(this.publicAuth.clientContact);
    this.form.controls['clientEmail'].setValue(this.publicAuth.clientEmail);
    this.DataService.currentSearchString.subscribe(
      async (data) => {
        this.searchString = data;
      }
    );
    this.DataService.currentMerchantTableFitPax.subscribe(
      data => {
        this.currentMerchantTableFitPax = data;
      }
    );
  }

  async submit() {
    this.spinner.show();
    try {
      if (this.DataService.publicAuth != undefined) {
        var data = {
          type: this.exchange.type,
          clientID: this.DataService.publicAuth.clientID,
          merchantID: this.exchange.merchantID,
          deliverTime: this.searchString.searchTime,
          reservationPax: this.searchString.searchPax,
          reservationName: this.form.controls.clientName.value,
          reservationContact: this.form.controls.clientContact.value,
          reservationEmail: this.form.controls.clientEmail.value,
          reservationRemarks: this.form.controls.clientRemarks.value,
        };
        console.log(data);
        var orderInfo = await this.API.createOrder(data);
        console.log(orderInfo.length);
        if (orderInfo.reservationID != undefined) {
          this.reservationStatus = true;
          this.DataService.syncData('info');
          // this.router.navigate(['payment']);
        } else if (orderInfo == 'tableFull') {
          this.modalEvent('tableFull')
        } else {
          this.reservationStatus = false;
          this.router.navigate(['home']);
        }
        console.log(orderInfo);
        // this.router.navigate(['payment']);
      }
    }
    catch (err) {
      console.error(err);
    }
    // $('#modal_cart').modal('hide');
    this.spinner.hide();
  }

  async modalEvent(type) {
    if (type == 'tableFull') {
      $('#modalTableFull').modal('show');
    }
  }

}
