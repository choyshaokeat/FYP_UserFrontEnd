import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DataService } from './services/data.service';
import { EncrDecrService } from './services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  login_status: boolean = false;
  reservationInfo = {
    date: '',
    time: '',
    duration: '',
    pax: '',
    shopID: ''
  }
  errorDetails: any;
  reservation_error_msg: string = '';
  today_date: string = '';
  date_3_months_later: string = '';
  today_time: string = '';

  location = {};

  constructor(
    private DataService: DataService,
    private EncrDecrService: EncrDecrService,
    private router: Router,
  ) { }

  async ngOnInit() {
    await this.serviceLogin();
    this.DataService.callAll();
    this.login_status = true;
    await this.subscribeData();
  }

  async subscribeData() {
    this.DataService.current_reservationInfo.subscribe(
      (data: { date, time, duration, pax, shopID }) => {
        this.reservationInfo.date = (data.date == undefined) ? '' : data.date;
        this.reservationInfo.time = (data.time == undefined) ? '' : data.time;
        this.reservationInfo.duration = (data.duration == undefined) ? '' : data.duration;
        this.reservationInfo.pax = (data.pax == undefined) ? '' : data.pax;
        this.reservationInfo.shopID = (data.shopID == undefined) ? '' : data.shopID;
      }
    );
    this.DataService.current_errorDetails.subscribe(
      async (data) => {
        this.errorDetails = data;
        if (this.errorDetails.trigger == true) {
          $('#modal_error').modal('show');
        }
      }
    );
  }

  async serviceLogin() {
    var auth = localStorage.getItem('auth');
    if (auth != undefined) {
      await this.DataService.updateClientInfo(auth);
    } else {
      this.DataService.updateClientInfo(this.EncrDecrService.encryptObject('client', 'guest'));
    }
  }

  onActivate(ref) {
    if (ref.searchReservationEvent != undefined) {
      ref.searchReservationEvent.subscribe((data) => {
        if (data) this.openModal('reservation');
        else if (data == false) this.closeModal('reservation');
      });
    }
    if (ref.loginOptionEvent != undefined) {
      ref.loginOptionEvent.subscribe((data) => {
        if (data) this.openModal('login');
        else if (data == false) this.closeModal('login');
      });
    }
  }

  openModal(type) {
    console.log(type);
    if (type == 'reservation') $('#reservationModal').modal('show');
    else if (type == 'login') $('#loginOption').modal('show');
  }

  closeModal(type) {
    console.log(type);
    if (type == 'reservation') $('#reservationModal').modal('hide');
    else if (type == 'login') $('#loginOption').modal('hide');
  }

  reservationInfo_search() {
    //  console.log(this.reservationInfo);
    this.reservation_error_msg = ``;
    if (this.reservationInfo.date == '' || this.reservationInfo.time == '' || this.reservationInfo.duration == '' || this.reservationInfo.pax == '') return this.reservation_error_msg = `Please select date/time/duration/pax!`;
    $('#reservationModal').modal('hide');
    this.DataService.update_reservationInfo(this.reservationInfo);
    this.router.navigate(['reservation']);
  }

  reset_reservationInfo() {
    this.reservation_error_msg = '';
    this.reservationInfo = {
      date: '',
      time: '',
      duration: '',
      pax: '',
      shopID: ''
    };
  }

}
