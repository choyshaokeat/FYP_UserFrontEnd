import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supportFAQ',
  templateUrl: './supportFAQ.component.html'
})
export class SupportFAQComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
