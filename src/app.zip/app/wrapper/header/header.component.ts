import { Component, OnInit, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../../services/api-front-end.service';
import { DataService } from '../../services/data.service';
import { EncrDecrService } from '../../services/encdec.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  login_status: boolean = false;

  currentCartList = [];
  currentMerchantInfo = {};
  quantity: number = 0;

  url: string = '';
  showSearchBar: boolean = false;
  searchString: string = '';

  editSearchString: boolean = false;
  disable_search: boolean = false;

  current_reservationInfo = {
    date: '',
    time: '',
    duration: '',
    pax: ''
  }

  today_date: string = '';
  date_3_months_later: string = '';
  today_time: string = '';
  listOfTime = [];
  duration = ['1/2', '1', '2', '2 ++'];
  listOfDuration: any;
  list_numOfPax = ['1-2', '3-5', '6-10', '11-15', '16 ++'];


  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService
  ) {

  }

  async ngOnInit() {
    this.DataService.current_loginDetails.subscribe(
      data => {
        if (typeof data == 'string') {
          if (data != '' && data != ' ' && data != undefined) {
            data = this.EncrDecrService.decryptObject('login', data);
          }
        }
        if (this.DataService.publicAuth == 'guest' || this.DataService.publicAuth == undefined) {
          this.login_status = false;
        } else this.login_status = true;
      }
    );

    this.router.events.subscribe((s) => {
      if (s['routerEvent'] != undefined) {
        this.showSearchBar = false;
        this.editSearchString = false;
        var url = s['routerEvent'].url;
        console.log(url);

        if (url != undefined && url != '' && url != ' ') {
          if (url == '/home') this.url = '/home';
          else if (url == '/explore') this.url = '/explore';
          else if (url == '/cart') this.url = 'cart';
          else if (url == '/settings') this.url = 'settings';
          else if (url.includes('/shop')) this.url = 'Shop';
          else if (url.includes('/restaurant_menu')) this.url = 'restaurant_menu';
          else if (url == '/queue') this.url = 'Queue';
        }
        if (this.url != '' && this.url != ' ') {
          this.showSearchBar = true;
          this.disable_search = false;
        }
      }
    });

    this.DataService.currentSearchString.subscribe(
      async (searchString) => {
        this.searchString = searchString;
      }
    );


    this.DataService.current_reservationInfo.subscribe(
      current_reservationInfo => {
        this.current_reservationInfo = current_reservationInfo;
      }
    );

  }

  change_editSearchString() {
    this.editSearchString = true;
  }

  async searchRestaurant() {
    if (this.searchString == '' || this.searchString == ' ' || this.searchString == undefined) return;
    let data = {
      searchString: this.searchString,
    }
    try {
      this.editSearchString = false;
      this.disable_search = true;
      var type;
      if (this.url == 'Dine In') type = 'dinein';
      else if (this.url == 'Reservation') type = 'reservation';
      else if (this.url == 'Shop') type = 'reservation';
      var resSearch = await this.DataService.search(data, undefined);
      this.disable_search = false;
      if (resSearch.length > 0) {
        console.log(resSearch);
        resSearch = await this.DataService.updateSearchResult(resSearch);
        this.router.navigate(['explore']);
      }
      else if (resSearch.length == 0) {
        console.error('Empty Data...');
        if (this.url == 'Dine In') this.router.navigate(['dine_in']);
        else if (this.url == 'Reservation') this.router.navigate(['reservation']);
        else if (this.url == 'Shop') this.router.navigate(['reservation']);
      }
    }
    catch (err) {
      this.disable_search = false;
      console.error(err);
    }
  }

  async chooseFromList(type, e) {
    // console.log(type, e);
    var filter_param = {
      date: this.current_reservationInfo.date,
      time: this.current_reservationInfo.time,
      duration: this.current_reservationInfo.duration,
      pax: this.current_reservationInfo.pax,
      searchString: this.searchString
    }
    try {
      var RES = await this.API.filter(filter_param);
      console.log(RES);
    }
    catch (err) {
      console.error(err);
    }
  }
}
