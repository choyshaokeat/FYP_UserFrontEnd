import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';


@Component({
  selector: 'app-dine',
  templateUrl: './dine.component.html',
  styleUrls: ['./dine.component.scss']
})
export class DineComponent implements OnInit {

  pub_merchant_id_error: boolean = false;

  cities: any;
  topPick_merchants: any;

  searchString: string = '';
  searchResult = [];

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private ActivatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private EncrDecrService: EncrDecrService
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    this.spinner.show();

    this.DataService.currentSearchString.subscribe(
      async (searchString) => {
        this.searchString = searchString;
      }
    );
    this.DataService.reset_merchantInfo();
    this.spinner.hide();
  }



  async check_merchant_from_merchant_info(merchantID) {
    if (merchantID == ' ' || merchantID == '' || merchantID == undefined) return;

    try {
      this.spinner.show();
      var res = await this.DataService.checkMerchantStatus(merchantID, this.spinner);
    }
    catch (err) {
      this.spinner.hide();
    }
  }

}
