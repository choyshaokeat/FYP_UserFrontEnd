import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policySalesFulfilment',
  templateUrl: './policySalesFulfilment.component.html'
})
export class PolicySalesFulfilmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
