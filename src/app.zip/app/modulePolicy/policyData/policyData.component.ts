import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policyData',
  templateUrl: './policyData.component.html'
})
export class PolicyDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
