import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policyRefund',
  templateUrl: './policyRefund.component.html'
})
export class PolicyRefundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
