import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { ApiBackEndService } from '../services/api-back-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';
import { environment } from '../../environments/environment';

declare var $: any;

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  data: any;
  cartList: any;
  merchantInfo: any = '';
  orderInfo: any = '';
  paymentInfo: any = false;

  currency: string = 'MYR';
  total: number = 0;
  paymentMethod;
  card_paymentType = {
    card_number: undefined,
    name: undefined,
    expiry_date: undefined,
    CVV: undefined,
    type: undefined
  }
  enable_button_placeOrder: boolean = false;
  addNewCard_boolean: boolean = false;
  cashPayment: boolean = false;
  eGHLDomain: any;

  eGHLExchange: any;
  eGHLHashObj_1: any;
  eGHLHash_1: any;
  eGHLHashObj_2: any;
  eGHLHash_2: any;

  params: any;
  exchange: any;
  routerNavigateData: any;

  //eGHL Payment Gateway
  TransactionType: any = '';
  PymtMethod: any = '';
  ServiceID: any = '';
  Password: any = '';
  OrderNumber: any = '';
  PaymentDesc: any = '';
  PaymentID: any = '';
  custName: any = '';
  custEmail: any = '';
  custPhone: any = '';
  merchantReturnURL: any = '';
  merchantCallBackURL: any = '';
  amount: any = '';
  currencyCode: any = '';
  custIP: any = '';
  LanguageCode: any = '';
  PageTimeout: any = '';
  Param6: any = '';
  Param7: any = '';

  publicAuth: any;

  cards = [
    {
      card_number: 111111111,
      name: 'aaaa',
      expiry_date: '11/2111',
      CVV: 111,
      type: 'VISA'
    },
    {
      card_number: 22222222,
      name: 'bbbb',
      expiry_date: '12/2222',
      CVV: 222,
      type: 'MASTERCARD'
    }
  ];

  constructor(
    private API: ApiFrontEndService,
    private ApiBackEndService: ApiBackEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService,
    private ActivatedRoute: ActivatedRoute,
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    await this.param();
    await this.subscribeData();
    console.log(this.orderInfo);
    this.spinner.hide();
  }

  async param() {
    console.log('param');
    this.ActivatedRoute.paramMap.subscribe(async (params) => {
      try {
        this.params = params['params'];
        if (this.params['exchange'] != undefined) {
          this.exchange = this.EncrDecrService.decryptObject('client', this.params['exchange']);
          console.log(this.exchange);
          console.log('params' + this.params);
          if (this.exchange != undefined && this.exchange != '') {
            this.paymentInfo = this.exchange[0];
            this.routerNavigateData = this.exchange[0];
            this.DataService.socketIO('emit', this.exchange[0]);
            this.DataService.syncData('info');
          }
        }
      }
      catch (err) {
        console.error(err);
      }
    });
  }

  async subscribeData() {
    this.publicAuth = this.DataService.publicAuth;
    this.DataService.currentMerchantInfo.subscribe(
      async data => {
        if (data != '' && data != ' ' && data != undefined) {
          data = this.EncrDecrService.decryptObject('client', data);
          this.merchantInfo = data;
        }
      }
    );
    this.DataService.currentOrderInfo.subscribe(
      async data => {
        this.orderInfo = data;
        this.orderInfo.totalAmount = parseFloat(this.orderInfo.totalAmount).toFixed(2);
      }
    );
    //eGHL Payment Gateway
    this.TransactionType = 'SALE';
    this.PymtMethod = 'ANY';
    this.ServiceID = environment.eGHLGatewayID;
    this.OrderNumber = this.orderInfo.orderID;
    this.PaymentDesc = "Foododo Order";
    this.custName = this.publicAuth.clientName;
    this.custEmail = this.publicAuth.clientEmail;
    this.custPhone = this.publicAuth.clientContact;
    this.merchantReturnURL = this.ApiBackEndService.getBackEndURL() + "/client/receivePayment";
    this.merchantCallBackURL = this.ApiBackEndService.getBackEndURL() + "/client/receivePayment";
    this.amount = this.orderInfo.totalAmount;
    this.currencyCode = "MYR";
    this.custIP = '127.0.0.1';
    this.LanguageCode = "en";
    this.PageTimeout = "780";
    this.Param6 = 'Ordering Foododo Alpha';
    this.Param7 = this.ApiBackEndService.getBackEndURL();
    console.log(this.publicAuth);
  }

  async generateEGHL(data) {
    console.log(data);
    this.PaymentID = data.paymentID;
    this.eGHLDomain = environment.eGHLDomain
    this.eGHLExchange =
      'TransactionType=' + encodeURIComponent(this.TransactionType) + '&' +
      'PymtMethod=ANY&' + encodeURIComponent(this.paymentMethod) + '&' +
      'ServiceID=' + encodeURIComponent(this.ServiceID) + '&' +
      'PaymentID=' + encodeURIComponent(this.PaymentID) + '&' +
      'OrderNumber=' + encodeURIComponent(this.OrderNumber) + '&' +
      'PaymentDesc=' + encodeURIComponent(this.PaymentDesc) + '&' +
      'MerchantReturnURL=' + encodeURIComponent(this.merchantReturnURL) + '&' +
      'MerchantCallBackURL=' + encodeURIComponent(this.merchantCallBackURL) + '&' +
      'Amount=' + encodeURIComponent(this.amount) + '&' +
      'CurrencyCode=' + encodeURIComponent(this.currencyCode) + '&' +
      'CustName=' + encodeURIComponent(this.custName) + '&' +
      'CustPhone=' + encodeURIComponent(this.custPhone) + '&CustEmail=' + encodeURIComponent(this.custEmail) + '&' +
      'CustIP=' + encodeURIComponent(this.custIP) + '&PageTimeout=' + this.PageTimeout + '&' +
      'LanguageCode=' + this.LanguageCode + '&' +
      'HashValue=' + data.paymentHash_1 + '&' +
      'Param6=' + this.Param6 + '&' +
      'Param7=' + this.Param7
  }

  async choosePaymentMethod(method) {
    this.paymentMethod = method;
    if (method == 1 || method == 3) this.enable_button_placeOrder = true;
    else this.enable_button_placeOrder = false;

    this.cashPayment = false;
    if (method == 1) {
      method = 'Cash';
      this.cashPayment = true;
    }
    else if (method == 2) method = 'Credit / Debit Card';
    else if (method == 3) method = 'Online Banking';
  }

  async proceedToPayment(paymentMethod) {
    console.log(this.orderInfo);
    try {
      this.spinner.show();
      if (paymentMethod == 'cash') {
        var paymentData = {
          type: paymentMethod,
          orderID: this.orderInfo.orderID,
          totalAmount: this.orderInfo.totalAmount,
          paymentMethod: this.paymentMethod,
          paymentCurrency: this.currencyCode,
          paymentReference: this.PaymentDesc,
          transactionType: this.TransactionType,
          pymtMethod: this.PymtMethod,
          Password: this.Password,
          serviceID: this.ServiceID,
          orderNumber: this.OrderNumber,
          paymentDesc: this.PaymentDesc,
          custEmail: this.custEmail,
          custPhone: this.custPhone,
          merchantReturnURL: this.merchantReturnURL,
          merchantCallBackURL: this.merchantCallBackURL,
          amount: this.orderInfo.totalAmount,
          currencyCode: this.currencyCode,
          custIP: this.custIP,
          languageCode: this.LanguageCode,
          pageTimeout: this.PageTimeout,
          param6: this.Param6,
          param7: this.Param7
        };
        var createPaymentData = await this.API.createPayment(paymentData);
        if (createPaymentData.status == 200) {
          this.paymentInfo = createPaymentData.data[0];
          this.routerNavigateData = this.orderInfo;
          this.orderInfo = undefined;
        }
      } else if (paymentMethod == 'eGHL') {
        var paymentData = {
          type: paymentMethod,
          orderID: this.orderInfo.orderID,
          totalAmount: this.orderInfo.totalAmount,
          paymentMethod: this.paymentMethod,
          paymentCurrency: this.currencyCode,
          paymentReference: this.PaymentDesc,
          transactionType: this.TransactionType,
          pymtMethod: this.PymtMethod,
          Password: this.Password,
          serviceID: this.ServiceID,
          orderNumber: this.OrderNumber,
          paymentDesc: this.PaymentDesc,
          custEmail: this.custEmail,
          custPhone: this.custPhone,
          merchantReturnURL: this.merchantReturnURL,
          merchantCallBackURL: this.merchantCallBackURL,
          amount: this.orderInfo.totalAmount,
          currencyCode: this.currencyCode,
          custIP: this.custIP,
          languageCode: this.LanguageCode,
          pageTimeout: this.PageTimeout,
          param6: this.Param6,
          param7: this.Param7
        };
        console.log(paymentData)
        var createPaymentData = await this.API.createPayment(paymentData);
        if (createPaymentData.status == 200) {
          await this.generateEGHL(createPaymentData.data);
          window.open(this.eGHLDomain + this.eGHLExchange, "_self");
        }
      }
    }
    catch (err) {
      console.error(err);
    }
    this.spinner.hide();
  }

  async routerNavigate() {
    console.log(this.routerNavigateData);
    if (this.routerNavigateData.orderType == 1 || this.routerNavigateData.orderType == 4) {
      this.router.navigate(['/history/orders']);
    } else if (this.routerNavigateData.orderType == 2 || this.routerNavigateData.orderType == 3) {
      this.router.navigate(['/history/reservation']);
    }
  }

  // PCI Compliance Release
  async chooseCard(card_number) {
    this.enable_button_placeOrder = true;
    this.card_paymentType = this.cards[0];
  }

  async changeAddNewCardBoolean() {
    this.addNewCard_boolean = !this.addNewCard_boolean;
    this.card_paymentType = {
      card_number: undefined,
      name: undefined,
      expiry_date: undefined,
      CVV: undefined,
      type: undefined
    };
  }

  async saveNewCard() {
    if (
      (this.card_paymentType.card_number != undefined && this.card_paymentType.card_number != '' && this.card_paymentType.card_number.length >= 16)
      && (this.card_paymentType.name != undefined && this.card_paymentType.name != '')
      && (this.card_paymentType.expiry_date != undefined && this.card_paymentType.expiry_date != '' && this.card_paymentType.expiry_date.length >= 4)
      && (this.card_paymentType.CVV != undefined && this.card_paymentType.CVV != '' && this.card_paymentType.CVV.length == 3)
    ) {
      this.card_paymentType.type = 'MASTERCARD';
      this.cards.push(this.card_paymentType);
      this.changeAddNewCardBoolean();
    }
  }
}
