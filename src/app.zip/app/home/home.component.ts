import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';
import * as moment from 'moment'

declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  @Output() searchReservationEvent: EventEmitter<any> = new EventEmitter();

  city: any;
  currentMerchantTableFitPax: any;
  availableReservationMerchant: any = '';
  availablePickngoMerchant: any = '';
  searchString: string = '';
  disable_search: boolean = false;
  topPick_merchants: any;
  searchResult: any;
  startDate: any;
  endDate: any;
  minDate: any;
  publicAuth: any;
  category: any;
  availableMerchant: any;
  modalData: any;
  filterCat: any = [];
  filterCity: any = [];
  noResult = false;

  form = this.fb.group({
    searchString: ['', [
      Validators.required,
    ]],
    searchTime: ['', [
      Validators.required,
    ]],
    searchPax: ['', [
      Validators.required,
    ]],
  })

  // Temp Variable
  list_numOfPax: any;
  current_reservationInfo: any;
  listOfDuration: any;
  listOfTime: any;
  date_3_months_later: string = '';
  today_date: any;
  filterDates: any;
  searchFormControl: any;

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private EncrDecrService: EncrDecrService,
    private fb: FormBuilder
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    this.searchString = '';
    this.DataService.updateSearchString(this.searchString);
    this.DataService.updateSearchResult([]);
    await this.subscribeData();
    await this.date_now();
    await this.setDataforSearch();
    await this.submit('reservationSearch');
    await this.submit('picknGoSearch');
    console.log(this.searchResult);
  }

  async date_now() {
    var start = moment();
    var remainder = 30 - (start.minute() % 30);
    var year = parseInt(moment(start).format("YYYY"));
    var month = parseInt(moment(start).format("MM"))-1;
    var day = parseInt(moment(start).format("D"));
    var hour = parseInt(moment(start).format("H"));
    var min = parseInt(moment(start).format("m"));
    var startHour = parseInt(moment(start).add(1, "hour").format("H"));
    var startMins = parseInt(moment(start).add(remainder, "minutes").format("m"));

    this.startDate = new Date(year, month, day, startHour, startMins);
    this.endDate = moment(this.startDate).add(14, "days").format();
    this.minDate = new Date(year, month, day, hour, min);
  }

  async setDataforSearch() {
    this.form.controls.searchString.setValue('Ipoh');
    this.form.controls.searchTime.setValue(this.startDate);
    this.form.controls.searchPax.setValue(1);
  }

  async subscribeData() {
    this.publicAuth = this.DataService.publicAuth;
    this.DataService.currentCity.subscribe(
      data => {
        this.city = data;
      }
    );
    this.DataService.currentMerchantTableFitPax.subscribe(
      data => {
        this.currentMerchantTableFitPax = data;
      }
    );
    this.DataService.currentMerchantCat.subscribe(
      data => {
        this.category = data;
      }
    );
    this.DataService.currentSearchString.subscribe(
      data => {
        this.searchString = data;
      }
    );
    this.DataService.currentSearchResult.subscribe(
      async (searchResult) => {
        var checkSearchResult: any;
        checkSearchResult = searchResult;
        if (checkSearchResult.reservation.length != 0 || checkSearchResult.picknGo.length != 0) {
          this.searchResult = searchResult;
        } else {
          this.searchResult = false;
        }
      }
    );
    await this.getAvailableMerchant();
  }

  async getAvailableMerchant() {
    try {
      let data1 = {type: 'reservation'}
      this.availableReservationMerchant = await this.API.getAvailableMerchant(data1);
      let data2 = {type: 'pickngo'}
      this.availablePickngoMerchant = await this.API.getAvailableMerchant(data2);
    }
    catch (err) {
      console.error(err);
    }
  }

  navigateTo(to) {
    this.router.navigate([`${to}`]);
  }

  openModal_reservationInfo_search() {
    this.searchReservationEvent.emit(true)
  }

  async searchRestaurant(type) {
    if (this.searchString == '' || this.searchString == ' ' || this.searchString == undefined) return;
    let data = {
      searchString: this.searchString,
    }
    try {
      this.disable_search = true;
      var resSearch = await this.DataService.search(data, type);
      // console.log(resSearch);
      this.disable_search = false;
      if (resSearch.length > 0) {
        this.router.navigate(['search']);
      }
      else if (resSearch.length == 0) {
        console.error('Empty Data');
      }
    }
    catch (err) {
      console.error(err);
    }
  }
  
  async search() {
    $('#filterModal').modal('hide');
    if (this.searchString == '' || this.searchString == ' ' || this.searchString == undefined) return;
    let data: any;
    data = this.searchString;
    data.filterCat = this.filterCat.toString();
    data.filterCity = this.filterCity.toString();
    try {
      this.disable_search = true;
      if (this.searchString['type'] == 'reservationSearch' || this.searchString['type'] == 'reservationFilter') {
        var resSearch = await this.DataService.search(data, 'reservationFilter');
      } else if (this.searchString['type'] == 'picknGoSearch' || this.searchString['type'] == 'picknGoFilter') {
        var resSearch = await this.DataService.search(data, 'picknGoFilter');
      }
      console.log(this.searchString['type'])
      // this.disable_search = false;
      if (resSearch.length == 0) {
        this.modalEvent('showErrorModal', null)
      }
    }
    catch (err) {
      console.error(err);
    }
  }

  async checkMerchantStatus(m, type) {
    console.log(m);
    console.log(this.searchString);
    $('#reservationModal').modal('hide');
    if (m.merchantID == ' ' || m.merchantID == '' || m.merchantID == undefined) return;
    let value = {
      type: type,
      merchantID: m.merchantID,
      merchantBizName: m.merchantBizName,
      merchantBizCity: m.merchantBizCity
    }
    console.log(value);
    try {
      this.spinner.show();
      var path = await this.EncrDecrService.encryptObject('client', value);
      console.log(path);
      if (type == 'reserveFood') {
        this.router.navigate(['cart/' + path]);
      } else if (type == 'reserveTable') {
        this.router.navigate(['confirmation/' + path]);
      } else if (type == 'picknGo') {
        this.router.navigate(['cart/' + path]);
      }
      this.spinner.hide();
    }
    catch (err) {
      this.spinner.hide();
    }
  }

  async filter_query(data, type) {
    if (type == 'cat') {                        // Catergory Filter
      if (this.filterCat.length == 0) {
        this.filterCat.push(data.id);
      } else {
        var checkFilterInList = false;
        this.filterCat.forEach((c, i) => {     // In the list
          if (c == data.id) {
            checkFilterInList = true;
            this.filterCat.splice(this.filterCat.indexOf(data.id), 1);
          }

        });
        if (!checkFilterInList) {               // Not In the list
          this.filterCat.push(data.id);
        }
      }
    } else if (type == 'city') {                // City Filter
      if (this.filterCity.length == 0) {
        this.filterCity.push(data.id);
      } else {
        var checkFilterInList = false;
        this.filterCity.forEach((c, i) => {    // In the list
          if (c == data.id) {
            checkFilterInList = true;
            this.filterCity.splice(this.filterCity.indexOf(data.id), 1);
          }

        });
        if (!checkFilterInList) {              // Not In the list
          this.filterCity.push(data.id);
        }
      }
    }
  }

  submit(type) {
    if (this.form.status === 'VALID') {
      return new Promise(async (resolve, reject) => {
        try {
          this.disable_search = true;
          var resSearch = await this.DataService.search(this.form.value, type);
          this.disable_search = false;
          if (resSearch.length > 0) {
            /* this.router.navigate(['explore']); */
            this.noResult = false;
          }
          else if (resSearch.length == 0) {
            this.noResult = true;
            console.error('Empty Data');
            this.modalEvent('modalEmpty', null);
          }
          resolve('ok');
        }
        catch (err) {
          console.error(err);
          reject(err);
        }
      });
    }
  }

  async modalEvent(type, data) {
    if (type == 'modalEmpty') {
      $('#modalEmpty').modal('show');
    } else if (type == 'filterModal') {
      $('#filterModal').modal('show');
    } else if (type == 'reservationModal') {
      this.modalData = data;
      $('#reservationModal').modal('show');
    } else if (type == 'showErrorModal') {
      this.modalData = data;
      $('#showErrorModal').modal('show');
    }
  }



}
