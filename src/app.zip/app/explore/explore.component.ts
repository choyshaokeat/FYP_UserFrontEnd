import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';
import * as moment from 'moment';

declare var $: any;

@Component({
  selector: 'app-explore',
  templateUrl: './explore.component.html',
  styleUrls: ['./explore.component.scss']
})
export class ExploreComponent implements OnInit {
  city: any;

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private EncrDecrService: EncrDecrService
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    //$('#filterModal').modal('show');
    await this.subscribeData();
  }

  async subscribeData() {
    this.DataService.currentCity.subscribe(
      data => {
        this.city = data;
      }
    );
  }

  navigateTo(to) {
    this.router.navigate([`${to}`]);
  }


}
