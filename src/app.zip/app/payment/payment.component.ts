import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  data: any;
  cartList: any;
  currentMerchantInfo = {
    merchantBizName: ''
  }

  currency: string = 'MYR';
  total: number = 0;
  paymentMethod;
  card_paymentType = {
    card_number: undefined,
    name: undefined,
    expiry_date: undefined,
    CVV: undefined,
    type: undefined
  }
  enable_button_placeOrder: boolean = false;
  addNewCard_boolean: boolean = false;
  cashPayment: boolean = false;

  cards = [
    {
      card_number: 111111111,
      name: 'aaaa',
      expiry_date: '11/2111',
      CVV: 111,
      type: 'VISA'
    },
    {
      card_number: 22222222,
      name: 'bbbb',
      expiry_date: '12/2222',
      CVV: 222,
      type: 'MASTERCARD'
    }
  ];

  qrcValue: string = 'undefined';


  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    this.spinner.show();

    var orderInfo = '';
    this.DataService.currentOrderInfo.subscribe(
      async (orderInfo) => {
        // console.log(orderInfo);
        this.cartList = [];
        this.currentMerchantInfo = {
          merchantBizName: ''
        };
        orderInfo = orderInfo;

        if (orderInfo == undefined || orderInfo == '') return;
        try {
          var order = await this.API.getDetails_by_order_id(orderInfo);
          // console.log(order);
          this.cartList = order.foodList;
          this.total = this.DataService.calculateTotal(this.cartList);
          this.currentMerchantInfo = {
            merchantBizName: order.merchantBizName
          };
          this.qrcValue = order.orderInfo;
        }
        catch (err) {
          console.error(err);
        }
      }
    );

    if ( orderInfo == '' ) return this.router.navigate(['dine_in']);
    this.spinner.hide();
  }

  choosePaymentMethod(method) {
    this.paymentMethod = method;
    if (method == 1 || method == 3) this.enable_button_placeOrder = true;
    else this.enable_button_placeOrder = false;

    this.cashPayment = false;
    if (method == 1) {
      method = 'Cash';
      this.cashPayment = true;
    }
    else if (method == 2) method = 'Credit / Debit Card';
    else if (method == 3) method = 'Online Banking';
  }

  chooseCard(card_number) {
    this.enable_button_placeOrder = true;
    this.card_paymentType = this.cards[0];
  }

  changeAddNewCardBoolean() {
    this.addNewCard_boolean = !this.addNewCard_boolean;
    this.card_paymentType = {
      card_number: undefined,
      name: undefined,
      expiry_date: undefined,
      CVV: undefined,
      type: undefined
    };
  }

  saveNewCard() {
    if (
      (this.card_paymentType.card_number != undefined && this.card_paymentType.card_number != '' && this.card_paymentType.card_number.length >= 16)
      && (this.card_paymentType.name != undefined && this.card_paymentType.name != '')
      && (this.card_paymentType.expiry_date != undefined && this.card_paymentType.expiry_date != '' && this.card_paymentType.expiry_date.length >= 4)
      && (this.card_paymentType.CVV != undefined && this.card_paymentType.CVV != '' && this.card_paymentType.CVV.length == 3)
    ) {
      this.card_paymentType.type = 'MASTERCARD';
      this.cards.push(this.card_paymentType);
      this.changeAddNewCardBoolean();
    }
  }

  async proceedToPayment() {
    try {
      var paymentMethod = '';
      if (this.paymentMethod == 1) paymentMethod = 'Cash';
      else if (this.paymentMethod == 2) {
        paymentMethod = 'Credit / Debit Card';
        if (this.card_paymentType.type == '' || this.card_paymentType.type == ' ' || this.card_paymentType.type == undefined) return;
      }
      else if (this.paymentMethod == 3) paymentMethod = 'Online Banking';

      this.spinner.show();
      var paymentData = {
        orderInfo: this.qrcValue,
        total_amount: this.DataService.calculateTotal(this.cartList),
        paymentMethod: paymentMethod,
        payment_type: this.card_paymentType.type,
        payment_reference: this.card_paymentType.card_number
      };
      var createPayment = await this.API.createPayment(paymentData);
      this.router.navigate(['history/orders']);
    }
    catch (err) {
      console.error(err);
    }
    this.spinner.hide();
  }
}
