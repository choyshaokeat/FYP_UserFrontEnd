import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ApiBackEndService {

  constructor(private http: HttpClient) { }

  getFrontEndURL() {
    return 'http://localhost:4200';
    return 'https://foododo.co';
  }

  getBackEndURL() {
    return 'http://localhost:8000';
    return 'https://api.foododo.co:8001';
  }

  // Client Info
  registerClient(data) {
    return this.http.post(`${this.getBackEndURL()}/client/registerClient`, { data }, httpOptions);
  }

  registerCheck(data) {
    return this.http.post(`${this.getBackEndURL()}/client/registerCheck`, { data }, httpOptions);
  }

  login(data) {
    return this.http.post(`${this.getBackEndURL()}/client/login`, { data }, httpOptions);
  }

  getClientInfo(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getClientInfo`, { data }, httpOptions);
  }

  updateClientInfo(data) {
    return this.http.post(`${this.getBackEndURL()}/client/updateClientInfo`, { data }, httpOptions);
  }

  // Basic Parameter
  getCountry(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getCountry`, { data }, httpOptions);
  }

  getCity(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getCity`, { data }, httpOptions);
  }

  getMerchantCat(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getMerchantCat`, { data }, httpOptions);
  }

  getMerchantTableFitPax(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getMerchantTableFitPax`, { data }, httpOptions);
  }

  getAvailableMerchant(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getAvailableMerchant`, { data }, httpOptions);
  }


  registerVerificationCode(data) {
    return this.http.post(`${this.getBackEndURL()}/agent/mail`, { data }, httpOptions);
  }



  getImageAPI() {
    return `${this.getBackEndURL()}/image/upload`;
  }

  //Cart
  checkMerchantStatus(data) {
    return this.http.post(`${this.getBackEndURL()}/client/checkMerchantStatus`, { data }, httpOptions);
  }

  getFoodType(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getFoodType`, { data }, httpOptions);
  }

  getFood(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getFood`, { data }, httpOptions);
  }

  createOrder(data) {
    return this.http.post(`${this.getBackEndURL()}/client/createOrder`, { data }, httpOptions);
  }


  // Search
  search(data) {
    return this.http.post(`${this.getBackEndURL()}/search/search`, { data }, httpOptions);
  }

  filter(data) {
    return this.http.post(`${this.getBackEndURL()}/search/filter`, { data }, httpOptions);
  }



  // Account
  getOrders(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getOrders`, { data }, httpOptions);
  }

  getOrdersDetails(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getOrdersDetails`, { data }, httpOptions);
  }

  getReservation(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getReservation`, { data }, httpOptions);
  }

  getReservationDetails(data) {
    return this.http.post(`${this.getBackEndURL()}/client/getReservationDetails`, { data }, httpOptions);
  }




  registerMerchant(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/register`, { data }, httpOptions);
  }

  check_merchant_from_merchant_info(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/check_merchant_from_merchant_info`, { data }, httpOptions);
  }

  get_foodtype() {
    return this.http.post(`${this.getBackEndURL()}/merchant/get_foodtype`, { data: undefined }, httpOptions);
  }

  getAllCities(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/getAllCities`, { data }, httpOptions);
  }



  getTopPicksMerchant_by_type(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/getTopPicksMerchant_by_type`, { data }, httpOptions);
  }

  getAvailableMerchant_by_type(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/getAvailableMerchant_by_type`, { data }, httpOptions);
  }

  getAvailableMerchant_by_date(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/getAvailableMerchant_by_date`, { data }, httpOptions);
  }

  getAllTables(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant/getAllTables`, { data }, httpOptions);
  }









  create_table_for_date(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant_opening/create_table_for_date`, { data }, httpOptions);
  }
  insert_data_to_table_date(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant_opening/insert_data_to_table_date`, { data }, httpOptions);
  }


  createDate(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant_opening/createDate`, { data }, httpOptions);
  }
  insertMerchantOpening(data) {
    return this.http.post(`${this.getBackEndURL()}/merchant_opening/insertMerchantOpening`, { data }, httpOptions);
  }












  getDetails_by_order_id(data) {
    return this.http.post(`${this.getBackEndURL()}/order/getDetails_by_order_id`, { data }, httpOptions);
  }

  getAllOrders(data) {
    return this.http.post(`${this.getBackEndURL()}/order/getAllOrders`, { data }, httpOptions);
  }

  getAchievedOrders(data) {
    return this.http.post(`${this.getBackEndURL()}/order/getAchievedOrders`, { data }, httpOptions);
  }







  createPayment(data) {
    return this.http.post(`${this.getBackEndURL()}/client/createPayment`, { data }, httpOptions);
  }








  get_date_time_pax_by_merchant_id(data) {
    return this.http.post(`${this.getBackEndURL()}/reservation/get_date_time_pax_by_merchant_id`, { data }, httpOptions);
  }

  make_reservation(data) {
    return this.http.post(`${this.getBackEndURL()}/reservation/make_reservation`, { data }, httpOptions);
  }


}

