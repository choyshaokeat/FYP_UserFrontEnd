import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ApiFrontEndService } from './api-front-end.service';
import { EncrDecrService } from './encdec.service';
import { SocketioService } from './socketio.service';
import * as moment from 'moment';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(
    private router: Router,
    private API: ApiFrontEndService,
    private EncrDecrService: EncrDecrService,
    private socketService: SocketioService,
  ) { }

  async socketIO(type, data) {
    if (type == 'emit') {
      console.log(data.merchantID);
      let syncData = {
        merchantID: data.merchantID,
        syncModule: 'kt_module',
      }
      this.socketService.emit('syncMerchant', syncData)
    } else if (type == 'listen') {
      this.socketService.listen('broadcastData').subscribe((data) => {
        this.updateBrodcastData(data);
        console.log(data);
      })
      this.socketService.listen('syncServer').subscribe((data) => {
        console.log(data);
      })
    }
  }

  async callAll() {
    return new Promise<any>(async (resolve, reject) => {
      try {
        console.log('callAll');
        // Socket IO
        await this.socketIO('listen', undefined);
        // Client Info
        // this.updateClientInfo(await this.getClientInfo(this.publicAuth_decrypted));
        this.updateOrders(await this.getOrders(this.publicAuth));
        this.updateReservation(await this.getReservation(this.publicAuth));
        this.updateSearchString(undefined);
        // Basic Paramter
        this.updateCountry(await this.getCountry());
        this.updateCity(await this.getCity());
        this.updateMerchantCat(await this.getMerchantCat());
        this.updateMerchantTableFitPax(await this.getMerchantTableFitPax());

        resolve('ok');
      }
      catch (err) {
        console.error(err);
        reject(err);
      }
    });
  }

  async syncData(module) {
    return new Promise<any>(async (resolve, reject) => {
      try {
        if (module == "info") {
          // Client Info
          var data = await this.getClientInfo(this.publicAuth);
          this.updateClientInfo(await this.EncrDecrService.encryptObject('client', data[0]));
          this.updateOrders(await this.getOrders(this.publicAuth));
          this.updateReservation(await this.getReservation(this.publicAuth));
        } else if (module == "basic_parameter") {
          // Basic Paramter
          this.updateCountry(await this.getCountry());
          this.updateCity(await this.getCity());
          this.updateMerchantCat(await this.getMerchantCat());
          this.updateMerchantTableFitPax(await this.getMerchantTableFitPax());
        }
        resolve('ok');
      }
      catch (err) {
        console.error(err);
        reject(err);
      }
    });
  }


  // Client Info
  async getClientInfo(value) {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getClientInfo(value);
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getOrders(value) {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getOrders(value);
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getOrdersDetails(value) {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getOrdersDetails(value);
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getReservation(value) {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getReservation(value);
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getReservationDetails(value) {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getReservationDetails(value);
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  // Basic Parameter
  async getCity() {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getCity();
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getCountry() {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getCountry();
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  async getMerchantCat() {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getMerchantCat();
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });

  }

  async getMerchantTableFitPax() {
    return new Promise(async (resolve, reject) => {
      try {
        var res = await this.API.getMerchantTableFitPax();
        resolve(res);
      }
      catch (err) {
        console.error(res, err);
        reject(err);
      }
    });
  }

  // Observable
  // SocketIO
  private brodcastData = new BehaviorSubject('');
  currentBrodcastData = this.brodcastData.asObservable();

  updateBrodcastData(value) {
    this.brodcastData.next(value);
  }
  // Service Aunthenticator
  public publicAuth: any;

  // Client Info
  private clientInfo = new BehaviorSubject('');
  currentClientInfo = this.clientInfo.asObservable();

  updateClientInfo(value) {
    this.clientInfo.next(value);
    this.publicAuth = this.EncrDecrService.decryptObject('client', value);
  }

  // Basic Parameter
  private country = new BehaviorSubject('');
  private city = new BehaviorSubject('');
  private merchantCat = new BehaviorSubject('');
  private merchantTableFitPax = new BehaviorSubject('');
  currentCountry = this.country.asObservable();
  currentCity = this.city.asObservable();
  currentMerchantCat = this.merchantCat.asObservable();
  currentMerchantTableFitPax = this.merchantTableFitPax.asObservable();

  updateCountry(value) {
    this.country.next(value);
  }

  updateCity(value) {
    this.city.next(value);
  }

  updateMerchantCat(value) {
    this.merchantCat.next(value);
  }

  updateMerchantTableFitPax(value) {
    this.merchantTableFitPax.next(value);
  }

  //Cart
  private merchantInfo = new BehaviorSubject('');
  currentMerchantInfo = this.merchantInfo.asObservable();
  updateMerchantInfo(value) {
    this.merchantInfo.next(value);
  }

  private cartList = new BehaviorSubject([]);
  currentCartList = this.cartList.asObservable();
  updateCartList(value) {
    this.cartList.next(value);
  }

  checkMerchantStatus(exchange, spinner) {
    let value = {
      type: exchange.type,
      merchantID: exchange.merchantID,
      tableID: exchange.tableID,
      date: moment().utc().format("YYYY-MM-DD"),
      status: 1,
    }
    console.log(value);
    return new Promise(async (resolve, reject) => {
      try {
        const res = await this.API.checkMerchantStatus(value);
        spinner.hide();
        if (res.length != 0) {
          var data = this.EncrDecrService.encryptObject('client', res[0]);
          this.updateMerchantInfo(data);
          resolve(res[0]);
        }
        else if (res.length == 0) {
          this.updateErrorDetails({
            title: 'Oopsss..',
            msg1: 'Restauant not available',
            msg2: 'Please find another',
            msg3: '',
            trigger: true
          });
          this.router.navigate([`home`]);
        } else {
          this.triggerErrorModal();
          this.router.navigate([`home`]);
        }
      }
      catch (err) {
        console.error(err);
        spinner.hide();
        this.triggerErrorModal();
        reject(err);
      }
    });
  }

  // Payment
  private orderInfo = new BehaviorSubject('');
  currentOrderInfo = this.orderInfo.asObservable();
  updateOrderInfo(value) {
    this.orderInfo.next(value);
  }

  // Search
  async search(data, type) {
    return new Promise<any>(async (resolve, reject) => {
      try {
        let uploadSearch: any;
        if (type == 'reservationSearch') {
          uploadSearch = {
            searchString: data.searchString,
            searchTime: data.searchTime,
            searchPax: data.searchPax,
            type: type
          };
        } else if (type == 'reservationFilter') {
          uploadSearch = {
            searchString: data.searchString,
            searchTime: data.searchTime,
            searchPax: data.searchPax,
            filterCat: data.filterCat,
            filterCity: data.filterCity,
            type: type
          };
        } else if (type == 'picknGoSearch') {
          uploadSearch = {
            searchString: data.searchString,
            searchTime: data.searchTime,
            type: type
          };
        } else if (type == 'picknGoFilter') {
          uploadSearch = {
            searchString: data.searchString,
            searchTime: data.searchTime,
            filterCat: data.filterCat,
            filterCity: data.filterCity,
            type: type
          };
        }
        var searchResult: any;
        searchResult = await this.API.search(uploadSearch);
        console.log(searchResult);

        let responseHome: any
        this.currentSearchResult.subscribe(
          data => {
            responseHome = data;
          }
        );
        if (responseHome == undefined) {
          responseHome.reservation = [];
          responseHome.picknGo = [];
        } else {
          if (type == 'reservationSearch' || type == 'reservationFilter') {
            responseHome.reservation = [];
          } else if (type == 'picknGoSearch' || type == 'picknGoFilter') {
            responseHome.picknGo = [];
          }
        }

        // console.log(searchResult);

        for (var count = 0; count < searchResult.length; count++) {
          // console.log(type);
          // console.log(searchResult[count].merchantOpenTime);
          // console.log(moment().format('HH:mm:ss'));
          // console.log(searchResult[count].merchantCloseTime);

          if (type == 'reservationSearch' || type == 'reservationFilter') {
            if (searchResult[count].merchantOpenTime <= moment().format('HH:mm:ss') && moment().format('HH:mm:ss') <= searchResult[count].merchantCloseTime) {
              searchResult[count].buttonStatus = true;
              responseHome.reservation.unshift(searchResult[count]);
            } else {
              searchResult[count].buttonStatus = false;
              responseHome.reservation.push(searchResult[count]);
            }
          } else if (type == 'picknGoSearch' || type == 'picknGoFilter') {
            if (searchResult[count].merchantOpenTime <= moment().format('HH:mm:ss') && moment().format('HH:mm:ss') <= searchResult[count].merchantCloseTime) {
              searchResult[count].buttonStatus = true;
              responseHome.picknGo.unshift(searchResult[count]);
            } else {
              searchResult[count].buttonStatus = false;
              responseHome.picknGo.push(searchResult[count]);
            }
          }

        }
        // console.log(responseHome);
        this.updateSearchString(uploadSearch);
        this.updateSearchResult(responseHome);
        resolve(searchResult);
      }
      catch (err) {
        reject(err);
      }
    });
  }

  private searchString = new BehaviorSubject('');
  currentSearchString = this.searchString.asObservable();
  updateSearchString(value) {
    if (value != undefined) {
      localStorage.setItem('searchString', this.EncrDecrService.encryptObject('client', value));
    }
    this.searchString.next(this.EncrDecrService.decryptObject('client', localStorage.getItem('searchString')));
  }
  private searchResult = new BehaviorSubject([]);
  currentSearchResult = this.searchResult.asObservable();
  updateSearchResult(value) {
    this.searchResult.next(value);
  }

  // Account
  private orders = new BehaviorSubject([]);
  currentOrders = this.orders.asObservable();
  updateOrders(value) {
    this.orders.next(value);
  }

  private ordersDetails = new BehaviorSubject([]);
  currentOrdersDetails = this.ordersDetails.asObservable();
  updateOrdersDetails(value) {
    this.ordersDetails.next(value);
  }

  private reservation = new BehaviorSubject([]);
  currentReservation = this.reservation.asObservable();
  updateReservation(value) {
    this.reservation.next(value);
  }

  private reservationDetails = new BehaviorSubject([]);
  currentReservationDetails = this.reservationDetails.asObservable();
  updateReservationDetails(value) {
    this.reservationDetails.next(value);
  }


  private loginDetails = new BehaviorSubject('');
  current_loginDetails = this.loginDetails.asObservable();
  update_loginDetails(value) {
    this.loginDetails.next(value);
  }

  private errorDetails = new BehaviorSubject({
    title: '',
    msg1: '',
    msg2: '',
    msg3: '',
    trigger: false
  });
  current_errorDetails = this.errorDetails.asObservable();
  updateErrorDetails(value) {
    this.errorDetails.next(value);
  }



  private reservationInfo = new BehaviorSubject({
    date: '',
    time: '',
    duration: '',
    pax: ''
  });
  current_reservationInfo = this.reservationInfo.asObservable();
  update_reservationInfo(value) {
    this.reservationInfo.next(value);
  }

  private selected_reservationInfo = new BehaviorSubject({});
  current_selected_reservationInfo = this.selected_reservationInfo.asObservable();
  update_current_selected_reservationInfo(value) {
    this.selected_reservationInfo.next(value);
  }



















  public triggerErrorModal() {
    this.updateErrorDetails({
      title: 'Oopsss..',
      msg1: 'Unexpected Error',
      msg2: 'Please contact administrator!',
      msg3: 'Sorry for inconvenience caused',
      trigger: true
    });
  }

  public reset() {
    this.updateClientInfo(this.EncrDecrService.encryptObject('client', 'guest'));
    localStorage.removeItem('auth');
    localStorage.removeItem('cart');
    this.reset_error();
    this.reset_merchantInfo();
    this.resetCart();
    this.reset_reservationInfo();
    this.reset_current_selected_reservationInfo();
  }

  public reset_error() {
    this.updateErrorDetails({
      title: '',
      msg1: '',
      msg2: '',
      msg3: '',
      trigger: false
    });
  }

  public reset_merchantInfo() {
    this.updateMerchantInfo('');
  }

  public resetCart() {
    this.updateCartList([]);
  }

  public reset_reservationInfo() {
    this.update_reservationInfo({});
  }

  public reset_current_selected_reservationInfo() {
    this.update_current_selected_reservationInfo({});
  }

  public resetOrderID() {
    this.updateOrderInfo('');
  }

  async login(spinner, user, url: boolean) {
    return new Promise<any>(async (resolve, reject) => {
      spinner.show();
      try {
        var res = await this.API.login(user);
        var data = {
          id: res[0].clientID,
          display_name_db: res[0].clientName,
          username_db: user.username,
          pwd_db: user.password,
          role_id_db: res[0].clientID,
          status: true
        };
        // console.log(data)
        var auth = this.EncrDecrService.encryptObject('login', data);
        this.update_loginDetails(auth);

        localStorage.auth = auth;
        spinner.hide();
        if (url != true) this.router.navigate(['/home']);
        resolve('logined');
      }
      catch (err) {
        console.error(err);
        spinner.hide();
        reject({ error: true });
      }
    });
  }

  calculateTotal(list) {
    var total = 0;
    list.forEach(cl => {
      cl.foodPrice = Number(cl.foodPrice).toFixed(2);
      if (cl.quantity > 0 && cl.foodPrice > 0) {
        total = total + (cl.quantity * cl.foodPrice);
      }
    });
    return total;
  }
}