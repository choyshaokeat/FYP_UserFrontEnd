import { Injectable } from '@angular/core';

import { ApiBackEndService } from '../services/api-back-end.service';
import { EncrDecrService } from '../services/encdec.service';

@Injectable({
  providedIn: 'root'
})
export class ApiFrontEndService {

  constructor(
    private ApiBackEndService: ApiBackEndService,
    private EncrDecrService: EncrDecrService
  ) { }

  // Client Info
  public registerClient(user) {
    return new Promise((resolve, reject) => {
      user = this.EncrDecrService.encryptObject('client', user);
      this.ApiBackEndService.registerClient(user).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  public registerCheck(data) {
    return new Promise((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.registerCheck(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }
  public login(user) {
    return new Promise((resolve, reject) => {
      user = this.EncrDecrService.encryptObject('login', user);
      this.ApiBackEndService.login(user).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('login', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  public getClientInfo(user) {
    return new Promise((resolve, reject) => {
      user = this.EncrDecrService.encryptObject('client', user);
      this.ApiBackEndService.getClientInfo(user).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            resolve(res.data);
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  public updateClientInfo(user) {
    return new Promise((resolve, reject) => {
      user = this.EncrDecrService.encryptObject('client', user);
      this.ApiBackEndService.updateClientInfo(user).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  public registerVerificationCode(data) {
    console.log(data);
    return new Promise((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('mail', data);
      this.ApiBackEndService.registerVerificationCode(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('mail', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  // Basic Parameter
  public getCountry() {
    let data = {};
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getCountry(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else if (res.status == 500) {
            res.data = 'Error';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getCity() {
    let data = {};
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getCity(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else if (res.status == 500) {
            res.data = 'Error';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getMerchantCat() {
    let data = {};
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getMerchantCat(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else if (res.status == 500) {
            res.data = 'Error';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getMerchantTableFitPax() {
    let data = {};
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getMerchantTableFitPax(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else if (res.status == 500) {
            res.data = 'Error';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public registerMerchant(user) {
    return new Promise((resolve, reject) => {
      user = this.EncrDecrService.encryptObject('merchant', user);
      this.ApiBackEndService.registerMerchant(user).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('merchant', res);
          if (res.status == 200) {
            if (res.data.length != 0) resolve(res.data)
            else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  // Cart
  public checkMerchantStatus(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.checkMerchantStatus(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else if (res.status == 500) {
            res.data = 'Error';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }


  public getFoodType(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getFoodType(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            if (res.data.length != 0) {
              resolve(res.data);
            }
            else if (res.data.length == 0) {
              reject('failed');
            }
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject('failed');
        }
      );
    });
  }

  public getFood(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getFood(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            if (res.data.length != 0) {
              resolve(res.data);
            }
            else if (res.data.length == 0) {
              reject('getFood data.length == 0');
            }
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }


  public search(data) {
    return new Promise((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('search', data);
      this.ApiBackEndService.search(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('search', res);
          if (res.status == 200) {
            resolve(res.data);
            // if (res.data.length != 0) resolve(res.data)
            // else if (res.data.length == 0) reject('Empty data');
          }
          else reject(res.status);
        },
        (err) => {
          reject(err)
        }
      );
    });
  }

  public filter(data) {
    data = this.EncrDecrService.encryptObject('search', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.filter(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('search', res);
          // console.log(res)
          if (res.status == 200) {
            // if (res.data.length != 0) {
            resolve(res.data);
            // }
            // else {
            //   reject('data.length == 0');
            // }
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  // Account

  public getOrders(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getOrders(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getOrdersDetails(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getOrdersDetails(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getReservation(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getReservation(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getReservationDetails(data) {
    return new Promise<any>((resolve, reject) => {
      data = this.EncrDecrService.encryptObject('client', data);
      this.ApiBackEndService.getReservationDetails(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getAllCities(data) {
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAllCities(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('merchant', res);
          // console.log(res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getAvailableMerchant(data) {
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAvailableMerchant(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('client', res);
          // console.log(res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getTopPicksMerchant_by_type(data) {
    data = this.EncrDecrService.encryptObject('merchant', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getTopPicksMerchant_by_type(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('merchant', res);
          // console.log(res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public getAvailableMerchant_by_type(data) {
    data = this.EncrDecrService.encryptObject('merchant', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAvailableMerchant_by_type(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('merchant', res);
          // console.log(res);
          if (res.status == 200) resolve(res.data);
          else reject(res);
        },
        (err) => {
          console.error(err);
          reject(err);
        }
      );
    });
  }

  public create_table_for_date(date) {
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.create_table_for_date(date).subscribe(
        (res: { status, data }) => {
          if (res.status == 200) resolve(res);
          else if (res.status == 500) {
            res.data = 'Already created';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public insert_data_to_table_date(data) {
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.insert_data_to_table_date(data).subscribe(
        (res: { status, data }) => {
          if (res.status == 200) resolve(res);
          else reject(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public createDate(date) {
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.createDate(date).subscribe(
        (res: { status, data }) => {
          if (res.status == 200) resolve(res);
          else if (res.status == 500) {
            res.data = 'Already created';
            resolve(res);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public insertMerchantOpening(data) {
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.insertMerchantOpening(data).subscribe(
        (res: { status, data }) => {
          if (res.status == 200) resolve(res);
          else reject(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public check_merchant_from_merchant_info(id) {
    id = this.EncrDecrService.encryptObject('merchant', id);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.check_merchant_from_merchant_info(id).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('merchant', res);
          // console.log(res);
          if (res.status == 200) resolve(res);
          else reject(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getAvailableMerchant_by_date(data) {
    data = this.EncrDecrService.encryptObject('reservation', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAvailableMerchant_by_date(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('reservation', res);
          // console.log(res)
          if (res.status == 200) {
            if (res.data.length != 0) {
              resolve(res.data);
            }
            else {
              reject('data.length == 0');
            }
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public createOrder(data) {
    data = this.EncrDecrService.encryptObject('client', data);
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.createOrder(data).subscribe(
        (res: { status, data }) => {
          res = this.EncrDecrService.decryptObject('client', res);
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getDetails_by_order_id(data) {
    data = this.EncrDecrService.encryptObject('order', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getDetails_by_order_id(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('order', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getAllOrders(data) {
    data = this.EncrDecrService.encryptObject('order', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAllOrders(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('order', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getAchievedOrders(data) {
    data = this.EncrDecrService.encryptObject('order', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAchievedOrders(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('order', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public createPayment(data) {
    data = this.EncrDecrService.encryptObject('client', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.createPayment(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('client', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res)
          }
          else {
            reject('failed');
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public make_reservation(data) {
    data = this.EncrDecrService.encryptObject('reservation', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.make_reservation(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('reservation', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject(res['message']);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public get_date_time_pax_by_merchant_id(data) {
    data = this.EncrDecrService.encryptObject('reservation', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.get_date_time_pax_by_merchant_id(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('reservation', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject(res['message']);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  public getAllTables(data) {
    data = this.EncrDecrService.encryptObject('merchant', data);
    // console.log(data)
    return new Promise<any>((resolve, reject) => {
      this.ApiBackEndService.getAllTables(data).subscribe(
        (res: { status, data }) => {
          // console.log(res);
          res = this.EncrDecrService.decryptObject('merchant', res);
          // console.log(res)
          if (res.status == 200) {
            resolve(res.data)
          }
          else {
            reject(res['message']);
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

}
