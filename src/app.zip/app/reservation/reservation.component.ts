import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.scss']
})
export class ReservationComponent implements OnInit {

  @Output() searchReservationEvent: EventEmitter<any> = new EventEmitter();

  current_reservationInfo = {
    date: '',
    time: '',
    duration: '',
    pax: ''
  }
  current_loginDetails = {
    id: '',
    display_name_db: '',
    username_db: '',
    pwd_db: '',
    role_id_db: '',
    timestamp_db: '',
    status: false
  };

  cities: any;
  topPick_merchants: any;
  list_numOfPax = ['1-2', '3-5', '6-10', '11-15', '16 ++'];
  selectedMerchant: any;

  today_date: string = '';
  date_3_months_later: string = '';
  today_time: string = '';
  listOfTime: any;
  duration = ['1/2', '1', '2', '2 ++'];
  listOfDuration: any;

  all_tables: any;
  invalidLogin: boolean = false;

  searchString: string = '';
  searchResult = [];

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private EncrDecrService: EncrDecrService,
    private router: Router,
    private ActivatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    this.spinner.show();
    this.DataService.current_loginDetails.subscribe(
      current_loginDetails => {
        if (current_loginDetails != '' && current_loginDetails != ' ' && current_loginDetails != undefined) {
          if (typeof current_loginDetails == 'string') {
            const auth = this.EncrDecrService.decryptObject('login', current_loginDetails);
            this.current_loginDetails = auth;
          }
        }
        // console.log(this.current_loginDetails)
      }
    );

    this.DataService.currentSearchString.subscribe(
      async (searchString) => {
        this.searchString = searchString;
      }
    );

    this.DataService.current_reservationInfo.subscribe(
      current_reservationInfo => {
        // console.log(current_reservationInfo);
        this.current_reservationInfo = current_reservationInfo;
      }
    );
  }
  
  openModal_reservationInfo_search() {
    this.searchReservationEvent.emit(true)
  }

  async set_SelectedMerchant(selectedMerchant, type, city) {
    var id = this.EncrDecrService.encryptObject('reservation', selectedMerchant);
    var regex = /(\/)/g;
    id = id.replace(regex, ':::');
    this.router.navigate([`shop/${id}`]);
    return;
  }

}
