import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";

import { Router, ActivatedRoute, Params } from '@angular/router';

// import { ApiService } from '../services/api.service';
import { ApiFrontEndService } from '../../services/api-front-end.service';
import { DataService } from '../../services/data.service';
import { EncrDecrService } from '../../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-shop-details',
  templateUrl: './shop-details.component.html',
  styleUrls: ['./shop-details.component.scss']
})
export class ShopDetailsComponent implements OnInit {

  @Output() loginOptionEvent: EventEmitter<any> = new EventEmitter();

  current_reservationInfo = {
    date: '',
    time: '',
    duration: '',
    pax: ''
  }
  current_loginDetails = {
    id: '',
    display_name_db: '',
    username_db: '',
    pwd_db: '',
    role_id_db: '',
    timestamp_db: '',
    status: false
  };

  cities: any;
  topPick_merchants: any;
  list_numOfPax = ['1-2', '3-5', '6-10', '11-15', '16 ++'];
  selectedMerchant: any;
  previousData_for_reserved: any;

  today_date: string = '';
  date_3_months_later: string = '';
  today_time: string = '';
  listOfTime: any;
  duration = ['1/2', '1', '2', '2 ++'];
  listOfDuration: any;

  all_tables: any;

  constructor(
    // private ApiService: ApiService,
    private API: ApiFrontEndService,
    private DataService: DataService,
    private EncrDecrService: EncrDecrService,
    private router: Router,
    private ActivatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scroll(0, 0);

    this.DataService.current_loginDetails.subscribe(
      current_loginDetails => {
        if (current_loginDetails != '' && current_loginDetails != ' ' && current_loginDetails != undefined) {
          if (typeof current_loginDetails == 'string') {
            const auth = this.EncrDecrService.decryptObject('login', current_loginDetails);
            this.current_loginDetails = auth;
          }
        }
        // console.log(this.current_loginDetails)
      }
    );

    this.ActivatedRoute.paramMap.subscribe(async (params) => {
      let p = params['params'];

      
      if (p['id'] != undefined) {
        try {
          var regex = /(:::)/g;
          var selectedMerchant = p['id'].replace(regex, '/');
          selectedMerchant = this.EncrDecrService.decryptObject('reservation', selectedMerchant);
          // console.log(selectedMerchant)
          if (typeof selectedMerchant == 'string') return this.router.navigate(['reservation']);
          // console.log(selectedMerchant);
          this.selectedMerchant = selectedMerchant;

          this.spinner.show();
          this.current_reservationInfo = {
            date: '',
            time: '',
            duration: '',
            pax: ''
          };

          this.all_tables = [];
          var getAllTables = await this.API.getAllTables(selectedMerchant);
          this.all_tables = getAllTables;
          // console.log(this.all_tables);
          this.list_numOfPax = [];
          this.all_tables.forEach(t => {
            this.list_numOfPax.push(t.fit_pax);
          });

          var res_reserved = await this.API.get_date_time_pax_by_merchant_id(selectedMerchant);
          // console.log(res_reserved)
          this.previousData_for_reserved = [];
          this.previousData_for_reserved = res_reserved;
          // console.log(this.previousData_for_reserved);

          this.spinner.hide();
        }
        catch (err) {
          console.error(err);
          this.spinner.hide();
        }
      }
    });
  }


  chooseFromList(type, value) {
    if (type == 'date') {
      var foundSameDate_from_reservedList = false;
      var reservedList_time = [];
      this.previousData_for_reserved.forEach(m => {
        if (m.reservation_date == value) {
          foundSameDate_from_reservedList = true;
          reservedList_time = m.time;
        }
      });

      this.current_reservationInfo['date'] = value;
      if (foundSameDate_from_reservedList) {
        this.current_reservationInfo['time'] = '';
        this.current_reservationInfo['duration'] = '';

        this.listOfTime.forEach(lt => {
          var lt_h = Number((lt.time).split(':')[0]);
          var tt_h = Number((this.today_time).split(':')[0]);
          if (value == this.today_date) {
            if (lt_h <= tt_h + 2) lt.valid = false;
          }
          else {
            lt.valid = true;
          }
        });

        reservedList_time.forEach(rlt => {
          var rlt_h = Number((rlt.startTime).split(':')[0]);

          this.listOfTime.forEach((lt, i) => {
            var lt_h = Number((lt.time).split(':')[0]);
            var lt_m = (lt.time).split(':')[1];
            if (rlt_h == lt_h) lt.valid = false;

            // need to compare the endTime/duration
            // fix it here 

          });

        });

      }
      else if (!foundSameDate_from_reservedList) {
        this.listOfTime.forEach(lt => {
          var lt_h = Number((lt.time).split(':')[0]);
          var tt_h = Number((this.today_time).split(':')[0]);
          if (value == this.today_date) {
            if (lt_h <= tt_h + 2) lt.valid = false;
          }
          else {
            lt.valid = true;
          }
        });
      }

    }
    else if (type == 'time') {
      this.current_reservationInfo['duration'] = '';
    }
    else if (type == 'duration') {
    }
    else if (type == 'pax') {
      for (var i = 0; i < this.all_tables.length; i++) {
        if (this.all_tables[i].fit_pax == this.current_reservationInfo['pax']) {
          this.selectedMerchant['tables'] = this.all_tables[i].tableID;
        }
      }
    }

    // console.log(this.current_reservationInfo);
    // console.log(this.selectedMerchant);
  }

  async submit(type) {
    try {
      console.log(this.current_reservationInfo)
      if (this.current_loginDetails.display_name_db === '') {
        return this.loginOptionEvent.emit(true);
      }

      let c = this.current_reservationInfo;
      if (
        c.date == undefined || c.time == undefined || c.duration == undefined || c.pax == undefined
        || c.date == '' || c.time == '' || c.duration == '' || c.pax == ''
      ) {
        return;
      }
      this.spinner.show();
      var data = {
        clientID: this.current_loginDetails['id'],
        merchantID: this.selectedMerchant['merchantID'],
        reservationInfo: this.current_reservationInfo,
        available_tables_id: this.selectedMerchant['tables']
      };
      // this.spinner.hide();
      // return console.log(data);
      data = await this.API.make_reservation(data);
      // console.log(data);
      $('#confirmReservation').modal('hide');
      this.DataService.reset_reservationInfo();
      if (type == 1) {
        this.spinner.hide();
        this.router.navigate(['history/reservation']);
      }
      else if (type == 2) {
        this.DataService.update_current_selected_reservationInfo(data);
        var res = await this.DataService.checkMerchantStatus(data.merchantID, this.spinner);
      }
    }
    catch (err) {
      $('#confirmReservation').modal('hide');
      console.error(`Type ${type}:`, err);
      this.spinner.hide();
      this.DataService.updateErrorDetails({
        title: 'Oopsss..',
        msg1: 'Full House!',
        msg2: 'Please try again with another restaurant/date/time',
        msg3: '',
        trigger: true
      });
    }
  }

}
