import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';

import { DataService } from '../services/data.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(
    private DataService: DataService,
    private router: Router,
  ) { }

  ngOnInit() {
    window.scroll(0, 0);
    this.DataService.reset();
    this.router.navigate(['/home']);
  }

}
