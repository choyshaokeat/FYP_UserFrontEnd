import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../../../services/api-front-end.service';
import { DataService } from '../../../services/data.service';
import { EncrDecrService } from '../../../services/encdec.service';

@Component({
  selector: 'app-loginLayout',
  templateUrl: './loginLayout.component.html',
  styleUrls: ['./loginLayout.component.scss']
})
export class LoginLayoutComponent implements OnInit {

  @Output() closeModal: EventEmitter<any> = new EventEmitter();

  user = {
    username: '',
    password: ''
  }

  errorOccured: boolean = false;
  showPassword_boolean: boolean = false;

  url: string = '';

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService,
    private ActivatedRoute: ActivatedRoute,
  ) { 
    this.ActivatedRoute.queryParamMap.subscribe((params) => {
      // console.log(params)
      if (params.has('value')) {
        try {
          var value = params.get('value');
          if ( typeof value != 'string' || !value ) throw 'Invalid value.';
          value = this.EncrDecrService.decryptObject('login', value);
          // console.warn(value);
          if ( !value['auth'] ) throw 'Invalid value..';
          value['auth'] = this.EncrDecrService.decryptObject('login', value['auth']);
          this.user = {
            username: value['auth']['username'],
            password: value['auth']['password']
          };
          // console.log(this.user)
          if ( !value['redirectTo'] ) throw 'Unable to redirect';
          if (value['redirectTo'].includes('/restaurant_menu')) this.url = 'restaurant_menu';
          else if (value['redirectTo'].includes('/shop')) this.url = 'shop';

          this.login(value['redirect'], value['redirectTo']);
        }
        catch(err) {
          console.error(err);
        }
        // var user = {
        //   username: '1',
        //   password: '1'
        // };
        // user = this.EncrDecrService.encryptObject('login', user);
        // console.log(user)
      }
    });
  }

  async ngOnInit() {
    window.scroll(0, 0);
    this.checkURL();
  }

  checkURL() {
    this.router.events.subscribe((s) => {
      if (s['routerEvent'] != undefined) {
        var url = s['routerEvent'].url;
        // console.log("url", url);

        this.url = '';
        if (url != undefined && url != '' && url != ' ') {
          if (url.includes('/restaurant_menu')) this.url = 'restaurant_menu';
          else if (url.includes('/shop')) this.url = 'shop';
        }
      }
    });
  }

  async login(redirect: boolean, redirectTo: string) {
    try {
      var url = false;
      if (this.url == 'restaurant_menu' || this.url == 'shop') url = true;
      var logined = await this.DataService.login(this.spinner, this.user, url);
      // console.log(logined, url, redirect, redirectTo)
      if (url && !redirect) {
        this.closeModal.emit('login');
      }
      else if (url && redirect) {
        this.router.navigate([`${redirectTo}`]);
      }
    }
    catch (err) {
      console.error(err);
    }
  }

  showPassword() {
    this.showPassword_boolean = !this.showPassword_boolean;
  }

  register() {
    this.router.navigate(['register'])
  }
}