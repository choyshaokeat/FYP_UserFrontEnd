import { Component, OnInit, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.scss']
})
export class TopnavComponent implements OnInit {

  login_status: boolean = false;

  currentCartList = [];
  currentMerchantInfo = {};
  quantity: number = 0;

  url: string = '';
  showSearchBar: boolean = false;
  searchString: string = '';

  editSearchString: boolean = false;
  disable_search: boolean = false;

  current_reservationInfo = {
    date: '',
    time: '',
    duration: '',
    pax: ''
  }

  today_date: string = '';
  date_3_months_later: string = '';
  today_time: string = '';
  listOfTime = [];
  duration = ['1/2', '1', '2', '2 ++'];
  listOfDuration: any;
  list_numOfPax = ['1-2', '3-5', '6-10', '11-15', '16 ++'];


  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService
  ) {

  }

  async ngOnInit() {
    this.DataService.current_loginDetails.subscribe(
      data => {
        // console.log(data)
        if (typeof data == 'string') {
          if (data != '' && data != ' ' && data != undefined) {
            data = this.EncrDecrService.decryptObject('login', data);
          }
        }
        // console.log(data)
        // console.log(data['status'] != undefined, data['status'] != false, data != '', data != undefined)
        if (data['status'] != undefined && data['status'] != false && data != '' && data != undefined) this.login_status = true;
        else this.login_status = false;
        // console.log(this.login_status)
      }
    );

    this.router.events.subscribe((s) => {
      if (s['routerEvent'] != undefined) {
        this.url = '';
        this.showSearchBar = false;
        this.editSearchString = false;
        var url = s['routerEvent'].url;
        // console.log("url", url);

        if (url != undefined && url != '' && url != ' ') {
          if (url == '/dine_in') this.url = 'Dine In';
          else if (url == '/reservation') this.url = 'Reservation';
          else if (url.includes('/shop')) this.url = 'Shop';
          else if (url.includes('/restaurant_menu')) this.url = 'restaurant_menu';
          else if (url == '/queue') this.url = 'Queue';
        }
        if (this.url != '' && this.url != ' ') {
          this.showSearchBar = true;
          this.disable_search = false;
        }
        // console.log(this.url)
      }
    });

    // console.log(this.login_status)
    // if (this.login_status == false) {
    //   var auth = localStorage.getItem('auth');
    //   // console.log(auth)
    //   if (auth != '' && auth != ' ' && auth != undefined) {
    //     auth = this.EncrDecrService.decryptObject('login', auth);
    //     // console.log(auth);

    //     if (auth['username_db'] != undefined && auth['pwd_db'] != undefined) {
    //       try {
    //         var user = {
    //           username: auth['username_db'],
    //           password: auth['pwd_db']
    //         }
    //         var url = false;
    //         if ( this.url == 'restaurant_menu' || this.url == 'Shop' ) url = true;
    //         console.log(url, this.url)
    //         var logined = await this.DataService.login(this.spinner, user, url);
    //       }
    //       catch (err) {
    //         console.error('Invalid Login Credential at localStorage');
    //       }
    //     }
    //   }
    // }

    this.DataService.currentSearchString.subscribe(
      async (searchString) => {
        this.searchString = searchString;
      }
    );

    this.DataService.currentCartList.subscribe(
      async (data) => {
        this.currentCartList = data;
        // console.log('topnav', this.currentCartList);
        if (data.length == 0) {
          var localData = localStorage.getItem('cart');
          if (localData != null && localData != undefined && localData != '')
            data = await this.EncrDecrService.decryptObject('cart', localData);
          if (data.length > 0) {
            this.currentMerchantInfo = data[0].currentMerchantInfo;
            this.currentCartList = data[0].data;
          }
        }
        else {
          this.currentMerchantInfo = data[0].currentMerchantInfo;
          this.currentCartList = data[0].data;
        }
        this.countQuantity();
      }
    );

    this.DataService.current_reservationInfo.subscribe(
      current_reservationInfo => {
        // console.log(current_reservationInfo);
        this.current_reservationInfo = current_reservationInfo;
      }
    );

    this.today_date = this.DataService.get_date(0, 0, 0);
    this.date_3_months_later = this.DataService.get_date(0, 3, 0);
    this.today_time = this.DataService.get_time();
    if (this.current_reservationInfo.date == '') {
      this.current_reservationInfo.date = this.today_date;
    }

    for (var hour = 0; hour < 24; hour++) {
      for (var min = 0; min < 60; min = min + 30) {
        var data = {
          time: `${this.DataService.add_zero_if_single_digit(hour)}:${this.DataService.add_zero_if_single_digit(min)}`,
          valid: true
        }
        this.listOfTime.push(data);
      }
    }
    this.listOfDuration = [];
    this.duration.forEach(d => {
      var p = {
        duration: d,
        valid: true
      }
      this.listOfDuration.push(p);
    });
  }

  countQuantity() {
    this.quantity = 0;
    for (var i = 0; i < this.currentCartList.length; i++) {
      let cl = this.currentCartList[i];
      this.quantity = this.quantity + Number(cl.quantity);
    }
  }

  change_editSearchString() {
    this.editSearchString = true;
  }

  async chooseFromList(type, e) {
    // console.log(type, e);
    var filter_param = {
      date: this.current_reservationInfo.date,
      time: this.current_reservationInfo.time,
      duration: this.current_reservationInfo.duration,
      pax: this.current_reservationInfo.pax,
      searchString: this.searchString
    }
    try {
      var RES = await this.API.filter(filter_param);
      console.log(RES);
    }
    catch(err) {
      console.error(err);
    }
  }
}
