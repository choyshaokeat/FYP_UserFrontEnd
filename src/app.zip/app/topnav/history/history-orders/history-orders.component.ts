import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { ApiFrontEndService } from '../../../services/api-front-end.service';
import { DataService } from '../../../services/data.service';
import { EncrDecrService } from '../../../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-history-orders',
  templateUrl: './history-orders.component.html',
  styleUrls: ['./history-orders.component.scss']
})
export class HistoryOrdersComponent implements OnInit {

  order_types = ['All', 'Achieved'];
  current_loginDetails: any;

  orders: any;

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scroll(0, 0);
    this.DataService.current_loginDetails.subscribe(
      current_loginDetails => {
        try {
          if ( typeof current_loginDetails == 'string' ) {
            current_loginDetails = this.EncrDecrService.decryptObject('login', current_loginDetails);
            this.current_loginDetails = current_loginDetails;
          }
        }
        catch(err) {
          console.error(err);
        }
      }
    );
    this.orders = [];
    this.getAllOrders();
  }

  selectOrderType(type) {
    // const yOffset = -100;
    // const element = document.getElementById(type);
    // const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
    // window.scrollTo({ top: y, behavior: 'smooth' });

    this.orders = [];
    if ( type == 'All' ) this.getAllOrders();
    else if ( type == 'Achieved' ) this.getAchievedOrders();
  }

  async getAllOrders() {
    this.spinner.show();
    try {
      if ( this.current_loginDetails != undefined ) {
        var getAllOrders = await this.API.getAllOrders(this.current_loginDetails['id']);
        console.log(getAllOrders);
        this.orders = getAllOrders;
      }
    }
    catch(err) {
      console.error(err);
    }
    this.spinner.hide();
  }

  async getAchievedOrders() {
    this.spinner.show();
    try {
      if ( this.current_loginDetails != undefined ) {
        var getAchievedOrders = await this.API.getAchievedOrders(this.current_loginDetails['id']);
        console.log(getAchievedOrders);
        this.orders = getAchievedOrders;
      }
    }
    catch(err) {
      console.error(err);
    }
    this.spinner.hide();
  }

}
