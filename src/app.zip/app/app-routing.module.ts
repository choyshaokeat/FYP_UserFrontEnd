import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { LoginLayoutComponent } from './login/loginLayout/loginLayout.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './wrapper/header/header.component';
import { FooterComponent } from './wrapper/footer/footer.component';
import { ErrorComponent } from './wrapper/error/error.component';
import { ExploreComponent } from './explore/explore.component';
import { HomeComponent } from './home/home.component';
import { SearchComponent } from './moduleSearch/search.component';


import { CameraComponent } from './moduleCamera/camera.component';
import { CartComponent } from './moduleCart/cart.component';
import { DineComponent } from './moduleDine/dine.component';
import { PaymentComponent } from './modulePayment/payment.component';


// import { DineinComponent } from './dine/dinein/dinein.component';
// import { PubShopProductsComponent } from './dine/pub-shop-products/pub-shop-products.component';
import { ReservationComponent } from './reservation/reservation.component';
import { ShopDetailsComponent } from './reservation/shop-details/shop-details.component';
// //import { PaymentComponent } from './payment/payment.component';
// import { SupportComponent } from './topnav/support/support.component';
// import { HistoryComponent } from './topnav/history/history.component';
// import { HistoryReservationComponent } from './topnav/history/history-reservation/history-reservation.component';
// import { HistoryOrdersComponent } from './topnav/history/history-orders/history-orders.component';
// import { QueueComponent } from './queue/queue.component';
// import { SettingsComponent } from './topnav/settings/settings.component';


import { ConfirmationComponent } from './moduleConfirmation/Confirmation.component';

import { AccountComponent } from './moduleAccount/account.component';
import { AccountHistoryComponent } from './moduleAccount/accountHistory/accountHistory.component';
import { AccountHistoryOrdersComponent } from './moduleAccount/accountHistory/accountHistoryOrders/accountHistoryOrders.component';
import { AccountHistoryReservationComponent } from './moduleAccount/accountHistory/accountHistoryReservation/accountHistoryReservation.component';
import { AccountSettingsComponent } from './moduleAccount/accountSettings/accountSettings.component';

import { PolicyComponent } from './modulePolicy/policy.component';
import { PolicyDataComponent } from './modulePolicy/policyData/policyData.component';
import { PolicyRefundComponent } from './modulePolicy/policyRefund/policyRefund.component';
import { PolicySalesFulfilmentComponent } from './modulePolicy/policySalesFulfilment/policySalesFulfilment.component';
import { SupportComponent } from './support/support.component';
import { SupportFAQComponent } from './support/supportFAQ/supportFAQ.component';
import { SupportHeaderComponent } from './support/supportHeader/supportHeader.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'register', component: RegisterComponent },

  { path: 'explore', component: ExploreComponent },
  { path: 'home', component: HomeComponent },
  { path: 'search', component: SearchComponent },

  { path: 'camera', component: CameraComponent },
  { path: 'cart', component: CartComponent },
  { path: 'cart/:exchange', component: CartComponent },
  { path: 'dine', component: DineComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'payment/:exchange', component: PaymentComponent },


  { path: 'reservation', component: ReservationComponent },
  { path: 'shop', component: ShopDetailsComponent },



  // { path: 'restaurant_menu', component: PubShopProductsComponent },
  // { path: 'restaurant_menu/:id', component: PubShopProductsComponent },
  // { path: 'reservation', component: ReservationComponent },
  // { path: 'shop/:id', component: ShopDetailsComponent },


  { path: 'account', component: AccountComponent },
  {
    path: 'history', component: AccountHistoryComponent,
    children: [
      { path: 'orders', component: AccountHistoryOrdersComponent },
      { path: 'reservation', component: AccountHistoryReservationComponent },
    ]
  },
  { path: 'settings', component: AccountSettingsComponent },

  { path: 'confirmation', component: ConfirmationComponent },
  { path: 'confirmation/:exchange', component: ConfirmationComponent },

  {
    path: 'policy', component: PolicyComponent,
    children: [
      { path: 'data', component: PolicyDataComponent },
      { path: 'refund', component: PolicyRefundComponent },
      { path: 'sales', component: PolicySalesFulfilmentComponent },
    ]
  },
  {
    path: 'support', component: SupportComponent,
    children: [
      { path: 'faq', component: SupportFAQComponent },
      { path: 'header', component: SupportHeaderComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
export const RoutingComponents = [
  LoginComponent,
  LoginLayoutComponent,
  LogoutComponent,
  RegisterComponent,
  HeaderComponent,
  FooterComponent,
  ErrorComponent,
  ExploreComponent,
  HomeComponent,
  SearchComponent,

  CameraComponent,
  CartComponent,
  DineComponent,
  PaymentComponent,

  AccountComponent,
  AccountHistoryComponent,
  AccountHistoryOrdersComponent,
  AccountHistoryReservationComponent,
  AccountSettingsComponent,

  ConfirmationComponent,

  PolicyComponent,
  PolicyDataComponent,
  PolicyRefundComponent,
  PolicySalesFulfilmentComponent,

  SupportComponent,
  SupportFAQComponent,
  SupportHeaderComponent,

  ReservationComponent,
  ShopDetailsComponent
]
