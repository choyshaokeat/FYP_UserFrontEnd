import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ZXingScannerComponent } from '@zxing/ngx-scanner';

import { Result } from '@zxing/library';

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';

declare var $: any;

@Component({
  selector: 'app-camera',
  templateUrl: './camera.component.html',
  styleUrls: ['./camera.component.scss']
})
export class CameraComponent implements OnInit {

  availableDevices: MediaDeviceInfo[];
  currentDevice: MediaDeviceInfo = null;
  hasDevices: boolean;
  hasPermission: boolean;
  qrResult: any;
  qrValid: boolean = null;
  publicAuth: any;

  constructor(
    private DataService: DataService,
    private router: Router,   
  ) { }

  async ngOnInit() {
    await this.subscribeData();
    console.log(this.publicAuth);
  }
  clearResult(): void {
    this.qrResult = null;
  }

  async subscribeData() {
    this.publicAuth = this.DataService.publicAuth;
  }

  onCodeResult(resultString: string): void {
    this.qrResult = resultString;
    this.checkQR(resultString);
    if (this.qrValid == true) {
      this.qrResult = this.qrResult.slice(24, 200);
      console.log(this.qrResult);
      this.router.navigate(['/cart/'+ this.qrResult ]);
    }
    this.clearMessage();

  }

  onHasPermission(has: boolean): void {
    this.hasPermission = has;
  }

  async checkQR(qrResult) {
    console.log(qrResult.slice(0, 24));
    console.log(qrResult);
    if (qrResult.slice(0, 24) == 'https://foododo.co/cart/') {
      this.qrValid = true;
    }else {
      this.qrValid = false;
    }
  }
  clearMessage() {
    setTimeout(() => {
      this.qrResult = null;
    }, 3000);
  }

  async modalEvent(type) {
    if (type == 'clientQR') {
      $('#clientQR').modal('show');
    }
  }
}
