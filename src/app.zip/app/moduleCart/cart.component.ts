import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { ApiFrontEndService } from '../services/api-front-end.service';
import { DataService } from '../services/data.service';
import { EncrDecrService } from '../services/encdec.service';
import * as moment from 'moment';
import { empty } from 'rxjs';

declare var $: any;

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
})
export class CartComponent implements OnInit {

  @Output() loginOptionEvent: EventEmitter<any> = new EventEmitter();

  current_loginDetails = {
    id: '',
    display_name_db: '',
    username_db: '',
    pwd_db: '',
    role_id_db: '',
    timestamp_db: '',
    status: false
  };

  table_no: string = 'A1';
  currency: string = 'MYR';
  total: number = 0;

  foodTypeList = [];
  foodList = [];
  cartList = [];
  showAds: any = false;
  quantity: any;

  merchantID: any = '';
  exchange: any = '';
  localData: any;
  params: any;

  fake: any = [];

  currentMerchantInfo: any = {};
  searchString: any;
  modalData: any = '';
  modalIndex: any = '';
  modalNotes: any = '';

  constructor(
    private API: ApiFrontEndService,
    private DataService: DataService,
    private router: Router,
    private EncrDecrService: EncrDecrService,
    private spinner: NgxSpinnerService,
    private ActivatedRoute: ActivatedRoute
  ) { }

  async ngOnInit() {
    window.scroll(0, 0);
    await this.serviceLogin();
    await this.subscribeData();
    await this.param();
  }

  async param() {
    this.ActivatedRoute.paramMap.subscribe(async (params) => {
      try {
        this.params = params['params'];
        if (this.params['exchange'] != undefined) {
          this.exchange = this.EncrDecrService.decryptObject('client', this.params['exchange']);
          if (this.exchange != undefined) {
            if (this.exchange.merchantID != this.localData[0].merchantID && this.localData[0].merchantID != undefined) {
              this.modalEvent('modal_swap_cart', null, null);
            } if (this.exchange.merchantID == this.localData[0].merchantID && this.localData[0].merchantID != undefined) {
              await this.getLocalStorageCart();
            } else {
              var res = await this.DataService.checkMerchantStatus(this.exchange, this.spinner);
              if (typeof res == 'object') {
                this.currentMerchantInfo = res;
                console.log(this.currentMerchantInfo);
                this.getMerchantFood();
              }
            }
          }
        } else {
          console.log('no param');
          if (localStorage.getItem('cart') == undefined) {
            console.log('1');
            this.DataService.resetCart();
            this.cartList = [];
            localStorage.removeItem("cart");
            this.showAds = true;
          } else {
            console.log('2');
            this.getLocalStorageCart();
          }
        }
      }
      catch (err) {
        console.error(err);
      }
    });
  }

  async getLocalStorageCart() {
    this.spinner.show();
    console.log(this.localData);
    if (this.localData[0] != '' && this.localData[0] != undefined && this.localData[0].type != undefined) {
      this.exchange = this.localData[0];
      var res = await this.DataService.checkMerchantStatus(this.localData[0], this.spinner);
      if (typeof res == 'object') {
        this.currentMerchantInfo = res;
        if (this.currentMerchantInfo.merchantID == this.localData[0].merchantID) {
          this.cartList = this.localData[0].data;
          this.countQuantity();
        } else {
          this.DataService.resetCart();
          this.cartList = [];
          localStorage.removeItem("cart");
        }
      }
    } else if (this.cartList.length == 0 || this.localData == undefined) {
      this.DataService.resetCart();
      this.cartList = [];
      localStorage.removeItem("cart");
      this.showAds = true;
      this.spinner.hide();
    }
    this.total = this.DataService.calculateTotal(this.cartList);
    this.getMerchantFood();
  }

  async getMerchantFood() {
    try {
      if (typeof this.currentMerchantInfo == 'object') {
        this.foodTypeList = await this.API.getFoodType(this.currentMerchantInfo);
        this.foodList = await this.API.getFood(this.currentMerchantInfo);
        this.spinner.hide();
      }
      else {
        this.spinner.hide();
        this.router.navigate([`home`]);
      }
    }
    catch (err) {
      this.spinner.hide();
      if (typeof err == 'string') {
        if (err == 'getFood data.length == 0') {
          this.DataService.updateErrorDetails({
            title: 'Oopsss..',
            msg1: `Restaurant (${this.currentMerchantInfo['merchantBizName']}) is currently not available!`,
            msg2: 'Please look for another restaurant',
            msg3: '',
            trigger: true
          });
          this.router.navigate(['home']);
        }
      }
      else this.DataService.triggerErrorModal();
    }
  }

  async subscribeData() {
    this.DataService.resetOrderID();
    this.localData = await this.EncrDecrService.decryptObject('client', localStorage.getItem('cart'));
    this.DataService.currentMerchantInfo.subscribe(
      data => {
        if (data != '' && data != ' ' && data != undefined) {
          data = this.EncrDecrService.decryptObject('client', data);
          this.currentMerchantInfo = data;
        }
      }
    );
    this.DataService.currentSearchString.subscribe(
      async (data) => {
        this.searchString = data;
      }
    );
    this.DataService.currentCartList.subscribe(
      async (data) => {
        if (data.length > 0) {
          if (this.currentMerchantInfo.merchantID == data[0].currentMerchantInfo.merchantID) {
            this.cartList = data[0].data;
          }
        }
        this.total = this.DataService.calculateTotal(this.cartList);
      }
    );
  }

  async serviceLogin() {
    var auth = localStorage.getItem('auth');
    if (auth != undefined) {
      await this.DataService.updateClientInfo(auth);
    }
  }

  scroll(type, id) {
    const yOffset = -50;
    const element = document.getElementById(type+id);
    const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
    window.scrollTo({ top: y, behavior: 'smooth' });
    // let el = document.getElementById(id);
    // el.scrollIntoView(true);
    console.log(y);
  }

  addToCart(product) {
    if (this.cartList.length == 0) {
      product.quantity = 1;
      this.cartList.push(product)
    }
    else {
      var checkIfTheProductIsInTheList = false;
      this.cartList.forEach((c, i) => {
        if (c.id == product.id) {
          checkIfTheProductIsInTheList = true;
          c.quantity = c.quantity + 1;
        }
      });

      if (!checkIfTheProductIsInTheList) {
        product.quantity = 1;
        var tempList = [];
        tempList.push(product);
        this.cartList.forEach((c, i) => {
          tempList.push(c)
        });
        this.cartList = tempList;
      }
    }
    this.total = this.DataService.calculateTotal(this.cartList);
    this.updateCartList();
    // console.log(this.cartList);
  }

  addNotes(index) {
    this.cartList[index].notes = this.modalNotes;
    this.updateCartList();
    $('#modalAddNotes').modal('hide');
    // console.log(this.cartList);
  }


  clearCart() {
    this.cartList = [];
    localStorage.removeItem("cart");
  }

  deleteQuantity(product) {
    product.quantity = product.quantity - 1;
    if (product.quantity == 0) {
      for (var i = 0; i < this.cartList.length; i++) {
        let list = this.cartList[i];
        if (list.id == product.id) {
          this.cartList.splice(i, 1);
          i = i - 1;
        }
      }
    }
    this.total = this.DataService.calculateTotal(this.cartList);
    this.updateCartList();
  }

  addQuantity(product) {
    product.quantity = product.quantity + 1;
    this.total = this.DataService.calculateTotal(this.cartList);
    this.updateCartList();
  }

  countQuantity() {
    this.quantity = 0;
    for (var i = 0; i < this.cartList.length; i++) {
      let cl = this.cartList[i];
      this.quantity = this.quantity + Number(cl.quantity);
    }
  }

  async checkOut() {
    if (this.cartList.length > 0) {
      if (this.DataService.publicAuth == 'guest' || this.DataService.publicAuth == undefined) {
        return this.loginOptionEvent.emit(true);
      }
      this.spinner.show();
      try {
        if (this.DataService.publicAuth != undefined) {
          console.log(this.searchString);
          var data = {
            type: this.exchange.type,
            clientID: this.DataService.publicAuth.clientID,
            merchantID: this.currentMerchantInfo.merchantID,
            tableID: this.currentMerchantInfo.tableID,
            city: this.currentMerchantInfo.city,
            data: this.cartList,
            totalAmount: this.total,
            reservationPax: this.searchString.searchPax,
            reservationName: this.DataService.publicAuth.clientName,
            reservationContact: this.DataService.publicAuth.clientContact,
            reservationEmail: this.DataService.publicAuth.clientEmail,
            deliverTime: this.searchString.searchTime,
          };
          let res = await this.DataService.checkMerchantStatus(data, this.spinner);
          if (res == ' ' || res == '' || res == undefined) return;
          var orderInfo = await this.API.createOrder(data);
          console.log(orderInfo);
          if (orderInfo=='tableFull'){
            this.modalEvent('modalTableFull', null, null)
          }else {
            this.DataService.updateOrderInfo(orderInfo);
            this.DataService.resetCart();
            this.cartList = [];
            localStorage.removeItem("cart");
            this.router.navigate(['payment']);
          }
        }
      }
      catch (err) {
        console.error(err);
      }
      $('#modal_cart').modal('hide');
      this.spinner.hide();
    }
  }

  updateCartList() {
    var time = moment().utc().format("YYYY-MM-DD hh:mm:ss.SSSS");
    var updated_cartList = [{
      type: this.exchange.type,
      clientID: this.DataService.publicAuth.clientID,
      merchantID: this.currentMerchantInfo.merchantID,
      data: this.cartList,
      created_time: time
    }];
    this.countQuantity();
    var enc = this.EncrDecrService.encryptObject('client', updated_cartList);
    localStorage.cart = enc;
    this.DataService.updateCartList(updated_cartList);
  }

  async swap_cart(type) {
    if (type == 'new') {
      localStorage.removeItem("cart");
      this.localData[0].merchantID = this.merchantID;
      $('#modal_swap_cart').modal('hide');
      await this.param();
    } else if (type == 'old') {
      $('#modal_swap_cart').modal('hide');
      this.router.navigate(['/cart'])
    }

  }

  async modalEvent(type, data, index) {
    if (type == 'modal_cart') {
      $('#modal_cart').modal('show');
    } else if (type == 'modalAddNotes') {
      this.modalData = data;
      this.modalIndex = index;
      if (this.modalData.notes != undefined) {
        this.modalNotes = this.modalData.notes;
      } else {
        this.modalNotes = "";
      }
      console.log(this.modalData);
      $('#modalAddNotes').modal('show');
    } else if (type == 'modal_swap_cart') {
      $('#modal_swap_cart').modal('show');
    }
    else if (type == 'modalTableFull') {
      $('#modalTableFull').modal('show');
    }
  }

}
